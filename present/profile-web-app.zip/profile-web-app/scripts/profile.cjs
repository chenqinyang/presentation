#!/usr/bin/env node
'use strict';

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync, execFile } = require('node:child_process');
const { promisify } = require('node:util');
const runFile = promisify(execFile);

function check(ok, message) {
  if (!ok) throw new Error(message);
}

function pwPackage() {
  return require.resolve('playwright/package.json', { paths: [process.cwd(), __dirname] });
}

function record(url, file) {
  check(['http:', 'https:'].includes(new URL(url).protocol), 'Use an HTTP(S) application URL.');
  check(file && !fs.existsSync(file), 'Choose a new recording filename.');
  const cli = path.join(path.dirname(pwPackage()), 'cli.js');
  const summary = file + '.network.json';
  check(!fs.existsSync(summary), 'Choose a new network summary filename.');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'profile-web-app-'));
  const har = path.join(dir, 'manual.har');
  try {
    const auth = process.env.PROFILE_STORAGE_STATE ? ['--load-storage', process.env.PROFILE_STORAGE_STATE] : [];
    const result = spawnSync(process.execPath, [cli, 'codegen', '--channel', 'chrome', '--target', 'javascript',
      '--viewport-size', '1280,720', ...auth, '--save-har', har, '--output', path.resolve(file), url], { stdio: 'inherit' });
    if (result.error) throw result.error;
    check(result.status === 0 && fs.existsSync(file), 'Recording did not finish. Inspect the browser or CLI error.');
    check(fs.existsSync(har), 'Actions saved. Chrome closed before the network recording was flushed.');
    const counts = new Map();
    for (const entry of JSON.parse(fs.readFileSync(har, 'utf8')).log.entries) {
      const resource = new URL(entry.request.url);
      if (['https:', 'http:'].includes(resource.protocol))
        counts.set(resource.origin, (counts.get(resource.origin) ?? 0) + 1);
    }
    fs.writeFileSync(summary, JSON.stringify({ requestsByOrigin: Object.fromEntries(counts) }, null, 2),
      { flag: 'wx', mode: 0o600 });
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
}

const defaultProfiles = [1, 2, 4].flatMap(cpu => [2, 5, 20].map(down => ({
  cpu, down, up: 2, latency: 80
})));

function validate(config) {
  const { journeys, profiles, repeats } = config;
  check(Array.isArray(journeys) && journeys.length && journeys.every(j =>
    typeof j?.name === 'string' && j.name && typeof j.run === 'function' &&
    (j.setup === undefined || typeof j.setup === 'function')), 'Each journey needs a name and a run(page) function.');
  check(new Set(journeys.map(j => j.name)).size === journeys.length, 'Use distinct journey names.');
  check(Number.isInteger(repeats) && repeats >= 1, 'repeats must be a positive integer.');
  check(Array.isArray(profiles) && profiles.length && profiles.every(p => p &&
    [p.cpu, p.down, p.up, p.latency].every(Number.isFinite) && p.cpu >= 1 &&
    p.down > 0 && p.up > 0 && p.latency >= 0), 'Invalid CPU or network profile.');
  check(new Set(profiles.map(p => [p.cpu,p.down,p.up,p.latency].join('/'))).size === profiles.length,
    'Duplicate profiles.');
}

async function sampleRss(browserCDP) {
  if (!['darwin', 'linux'].includes(process.platform)) return null;
  try {
    const { processInfo } = await browserCDP.send('SystemInfo.getProcessInfo');
    const ids = processInfo.map(p => p.id).filter(id => id > 0);
    if (!ids.length) return null;
    const { stdout } = await runFile('ps', ['-o', 'rss=', '-p', ids.join(',')], { timeout: 1500 });
    const values = stdout.trim().split(/\s+/).map(Number);
    if (!values.every(n => Number.isFinite(n) && n > 0)) return null;
    return values.reduce((a,b) => a+b, 0) / 1024;
  } catch { return null; } // Some hosts restrict process inspection.
}

function observe(pageCDP, browserCDP) {
  const origins = {};
  const requests = new Map();
  let active = false;
  let peakHeapMiB = null;
  let peakChromeRssMiB = null;
  let pending = null;
  let timer;
  pageCDP.on('Network.requestWillBeSent', ({ requestId, request }) => {
    if (!active) return;
    try {
      const url = new URL(request.url);
      if (['http:', 'https:'].includes(url.protocol)) requests.set(requestId, url.origin);
    } catch {}
  });
  pageCDP.on('Network.loadingFinished', ({ requestId, encodedDataLength }) => {
    const origin = requests.get(requestId);
    if (!active || !origin) return;
    const group = origins[origin] ??= { bytes: 0, responses: 0 };
    group.bytes += encodedDataLength;
    group.responses++;
    requests.delete(requestId);
  });
  async function sample() {
    const [heap, rss] = await Promise.all([
      pageCDP.send('Runtime.getHeapUsage').then(v => v.usedSize / 1048576).catch(() => null),
      sampleRss(browserCDP)
    ]);
    if (heap !== null) peakHeapMiB = Math.max(peakHeapMiB ?? 0, heap);
    if (rss !== null) peakChromeRssMiB = Math.max(peakChromeRssMiB ?? 0, rss);
  }
  return {
    async start() {
      await sample();
      active = true;
      timer = setInterval(() => { if (!pending) pending = sample().finally(() => { pending = null; }); }, 500);
    },
    async stop() {
      active = false;
      clearInterval(timer);
      await pending;
      await sample();
      return { origins, peakHeapMiB, peakChromeRssMiB };
    }
  };
}

async function bounded(action, ms) {
  let timer;
  try {
    await Promise.race([action(), new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error('Journey deadline exceeded')), ms);
    })]);
  } finally { clearTimeout(timer); }
}

async function trial(browser, browserCDP, journey, profile, config) {
  const context = await browser.newContext({ viewport: { width: 1280, height: 720 },
    ...(config.storageState ? { storageState: config.storageState } : {}) });
  try {
    context.setDefaultTimeout(30000);
    const page = await context.newPage();
    const cdp = await context.newCDPSession(page);
    await cdp.send('Network.enable');
    await cdp.send('Emulation.setCPUThrottlingRate', { rate: profile.cpu });
    await cdp.send('Network.emulateNetworkConditions', { offline: false, latency: profile.latency,
      downloadThroughput: profile.down * 125000, uploadThroughput: profile.up * 125000 });
    if (journey.setup) {
      try { await bounded(() => journey.setup(page), 60000); }
      catch (error) { return { status: 'setup-failed', error: error.message.split('\n')[0] }; }
    }
    const observer = observe(cdp, browserCDP);
    await observer.start();
    const start = performance.now();
    let status = 'ok';
    let reason;
    try {
      await bounded(() => journey.run(page), 30000);
    } catch (error) {
      status = 'failed';
      reason = error.message.split('\n')[0];
    }
    const ms = performance.now() - start;
    return { status, ms, error: reason, ...await observer.stop() };
  } finally { await context.close(); }
}

async function bench(configFile, output) {
  check(configFile && output, 'bench needs a journey .cjs and a new results file.');
  const config = { profiles: defaultProfiles, repeats: 3, ...require(path.resolve(configFile)) };
  validate(config);
  const fd = fs.openSync(output, 'wx', 0o600);
  const { chromium } = require(path.dirname(pwPackage()));
  let browser;
  const write = item => fs.writeSync(fd, JSON.stringify(item) + '\n');
  try {
    browser = await chromium.launch({ channel: 'chrome', headless: config.headless ?? false });
    const cdp = await browser.newBrowserCDPSession();
    const cpus = os.cpus();
    write({ kind: 'plan', version: 1, date: new Date().toISOString(), build: config.build ?? 'unspecified',
      cpu: cpus[0]?.model, logicalCpus: cpus.length, ramGiB: os.totalmem()/2**30,
      os: [os.platform(), os.release(), os.arch()].join(' '), chrome: browser.version(),
      headless: config.headless ?? false, repeats: config.repeats, journeys: config.journeys.map(j => j.name),
      profiles: config.profiles });
    for (let i = 0; i < config.repeats; i++) {
      for (let k = 0; k < config.profiles.length; k++) {
        const index = (k+i) % config.profiles.length;
        for (const journey of config.journeys) {
          const row = await trial(browser, cdp, journey, config.profiles[index], config);
          write({ kind: 'trial', repeat: i+1, profile: index, journey: journey.name, ...row });
          console.log(journey.name, config.profiles[index], i+1, row.status, row.ms?.toFixed(0) ?? '', row.error ?? '');
        }
      }
    }
    write({ kind: 'complete' });
  } finally {
    fs.closeSync(fd);
    if (browser) await browser.close();
  }
}

function report(file, seconds) {
  const target = Number(seconds);
  check(Number.isFinite(target) && target >= 1 && target <= 15, 'Choose a target from 1 to 15 seconds.');
  const [plan, ...entries] = fs.readFileSync(file, 'utf8').trim().split('\n').map(s => JSON.parse(s));
  check(plan.kind === 'plan' && plan.version === 1 && entries.at(-1)?.kind === 'complete',
    'Incomplete or unsupported sweep. Run a complete sweep before making support claims.');
  const rows = entries.filter(e => e.kind === 'trial');
  const peak = values => values.length ? Number(Math.max(...values).toFixed(2)) : null;
  const profiles = plan.profiles.map((profile,index) => {
    const journeys = plan.journeys.map(name => {
      const group = rows.filter(r => r.profile === index && r.journey === name);
      const ok = group.filter(r => r.status === 'ok' && Number.isFinite(r.ms) && r.ms >= 0);
      const hits = ok.filter(r => r.ms <= target*1000).length;
      const complete = group.length === plan.repeats &&
        Array.from({ length: plan.repeats }, (_,i) => i+1).every(i => group.some(r => r.repeat === i));
      const maxMetric = key => peak(group.map(r => r[key]).filter(Number.isFinite));
      return { name, hits, attempts: group.length, errors: group.length-ok.length,
        passes: complete && hits === plan.repeats, slowestSuccessMs: peak(ok.map(r => r.ms)),
        maxSampledHeapMiB: maxMetric('peakHeapMiB'), maxSampledChromeRssMiB: maxMetric('peakChromeRssMiB'),
        maxCompletedTransferKiB: peak(ok.map(r => Object.values(r.origins).reduce((n,g) => n+g.bytes,0)/1024)) };
    });
    return { ...profile, passes: journeys.every(j => j.passes), journeys };
  });
  const passing = profiles.filter(p => p.passes);
  // Keep jointly observed profiles with no equally or more constrained passing alternative.
  const frontier = passing.filter(p => !passing.some(q => q !== p && q.cpu >= p.cpu && q.down <= p.down &&
    q.up <= p.up && q.latency >= p.latency));
  console.log(JSON.stringify({ targetSeconds: target, device: plan, leastDemandingPassingProfiles: frontier.map(
    ({ journeys, passes, ...p }) => p), profiles }, null, 2));
}

async function main() {
  const [mode, a, b] = process.argv.slice(2);
  if (mode === 'record') return record(a, b);
  if (mode === 'bench') return bench(a, b);
  if (mode === 'report') return report(a, b);
  throw new Error('Usage: profile.cjs record URL recording.js | bench journey.cjs results.jsonl | report results.jsonl SECONDS');
}
main().catch(error => { console.error(error.message); process.exitCode = 1; });
