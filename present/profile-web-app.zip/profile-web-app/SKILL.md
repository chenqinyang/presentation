---
name: profile-web-app
description: Record a user's manual journey in visible Chrome with Playwright, replay it under measured CPU and network profiles, and evaluate client hardware, memory, and bandwidth for a 1–15 second target chosen after testing. Use for web apps including React hosts with federated remote UIs.
---

# Profile a web application

Run the tools for the user. They operate Chrome during the demonstration and can choose a time target after the sweep. If they provide only a target and there is a saved sweep for this application and journey, go directly to **Answer a time target**.

## Record the user's journey

Use an isolated local work directory for recordings, private authentication state, and results. The helper runs on Node 18+ with Playwright and installed Google Chrome. Resolve `scripts/profile.cjs` relative to this skill. Run it from the project or profiling work directory with a resolvable `playwright` package. A bundled module directory can be supplied via `NODE_PATH`. If needed, install Playwright locally in the profiling work directory.

1. Get the URL if missing. Launch the following as a long-running process in the user's graphical desktop session. Keep it alive while the user takes control. Tell them which Chrome window to use, to perform the real workflow once, and to close the recording window normally when done. Coordinate through chat if they signal completion first. Avoid taking over their mouse or using their everyday Chrome profile.
   
   ```sh
   node "$SKILL/scripts/profile.cjs" record "$APP_URL" manual.js
   ```

2. The recorder saves Playwright actions and a network request count by origin in `manual.js.network.json`. Playwright briefly stores a private HAR during recording. The helper removes it after summarizing. Recorded inputs can appear literally in the local action script. For sign-in, first use Playwright's `open --channel chrome --save-storage state.json` locally to let the user authenticate outside the recorder, then set `PROFILE_STORAGE_STATE` to that file when recording and pass its path to the sweep. Check that the session restores. Keep credentials, recording and state files out of shared deliverables.
3. Read the recorded actions. Identify the trigger and the first observable usable outcome for each distinct task, such as opening Orders and seeing its populated table with an enabled row action. Infer the checkpoint from the demonstration when clear. Ask which outcome counts if ambiguous. Tell the user what each timer covers. Only replay actions that are repeatable on the supplied environment. For a purchase, send, deletion or similar side effect, use an authorized resettable fixture or stop the measured journey before committing the change.

## Replay and measure

Create a trusted local `journey.cjs` using the recorded locators. The runner loads this file as code. Adapt the following shape to the actual app. Use a data-dependent postcondition that changes after the trigger. Include any required enabled check as well as visibility. A successful first visit can check an actual navigation response or a distinctive loaded component. Keep sign-in, human pauses, fixed sleeps and unrelated setup outside the measured interval.

```js
const appUrl = process.env.APP_URL;
module.exports = {
  build: 'replace with tested deployment or build identifier',
  storageState: process.env.PROFILE_STORAGE_STATE,
  repeats: 3,
  journeys: [{
    name: 'Open Orders from the loaded host',
    async setup(page) {
      await page.goto(appUrl, { waitUntil: 'domcontentloaded' });
      await page.getByRole('link', { name: 'Orders' }).waitFor();
    },
    async run(page) {
      await page.getByRole('link', { name: 'Orders' }).click();
      const rowAction = page.getByTestId('first-loaded-order').getByRole('button', { name: 'Open' });
      await rowAction.click({ trial: true }); // waits for actionability without executing the click
    }
  }]
};
```

- For **cold entry**, put `page.goto(url, {waitUntil:'commit'})` and the ready check inside `run`. Each trial uses a fresh browser context. For **remote switching** or a **warm visit**, load or prime the intended state in `setup`, then switch or revisit in `run` in that same context. Include prefetch costs in a cold journey if the host starts loading remotes early.
- Do a single-profile, single-repeat pilot to check locators, app state, and permissions. Save the pilot separately. Then run the sweep, preferably against a production build with representative data. The default matrix tests CPU slowdowns of 1×, 2× and 4× crossed with download caps of 2, 5 and 20 Mbps, upload capped at 2 Mbps and 80 ms configured latency. These are test points. Change them to match the audience, or supply an array such as `profiles: [{cpu: 1, down: 10, up: 3, latency: 40}]`. Vary upload and latency independently if the workflow depends on them. Keep the device's power mode and background load comparable.
- Run `node "$SKILL/scripts/profile.cjs" bench journey.cjs results.jsonl`. Use a new results filename per run. Keep the completed JSONL and the journey together so later questions can reuse them. Calibration can proceed before the user chooses a target. Three repeats give an exploratory result. Retest borderline configurations with more repeats before publishing a support specification.
- The helper measures elapsed time through the asserted outcome, success/failure, main-page completed-transfer bytes grouped by origin, sampled JS heap and, on macOS/Linux where process inspection works, summed RSS for the dedicated Chrome processes. Sampling includes the boundaries and runs every 500 ms. RSS includes browser overhead and can count shared pages more than once. Heap covers the inspected target. Both can miss brief peaks. Network totals cover HTTP(S) requests started and completed during the measured interval. In-flight streams, worker traffic, redirects and traffic from other browser targets can make totals incomplete.
- The supplied harness applies throttles to one page target. For journeys involving popups, out-of-process iframes, or workers handling significant data or CPU, establish coverage before using the result as a requirement. Use device/network-level shaping or extend collection to those targets when needed. Identify a run that never reaches its checkpoint as a failed trial, and diagnose repeated setup failures before interpreting hardware.

## Answer a time target

Run the report for the requested number, including a decimal if desired. If no target has been supplied, summarize the completed coverage and invite a value from 1 to 15 seconds. Keep the result path available.

```sh
node "$SKILL/scripts/profile.cjs" report results.jsonl 5
```

Report the exact journey, target, build, Chrome version and tested physical host CPU/RAM. Give the jointly passing CPU slowdown, download/upload caps and configured latency, with hits/attempts and slowest successful time for each journey. Include sampled memory with units and scope. A profile passes when every recorded repetition of every selected journey succeeds within the chosen threshold. `leastDemandingPassingProfiles` retains trade-offs, e.g. a slower CPU with a faster link versus a faster CPU with a slower link. Keep each observed combination intact. For a target applying to only one journey, filter using its own trial outcomes. If none pass, report the fastest complete successful profile and the gap, or explain that there was no successful profile. If every profile passes, the lower boundary remains open.

CPU slowdown is relative to the named machine. Only native-rate runs on actual hardware validate that device's CPU, and installed RAM identifies a *tested capacity*. A single machine's timings or sampled Chrome memory cannot establish minimum GHz, core count or system RAM. When a concrete device minimum is requested, run the same build, journeys, profiles and target on candidate physical devices or resource-limited VMs and label which were physical versus virtual. Report the least capable configurations actually demonstrated and identify lower configurations still untested. For network results label the applied caps and latency; a lab pass is conditional on the tested server, cache state and underlying link.
