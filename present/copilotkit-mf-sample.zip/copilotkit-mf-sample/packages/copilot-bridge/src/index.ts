/**
 * copilot-bridge: a React-free singleton shared by Host, Content UI and AI Panel.
 *
 * - Content UI registers context / tools / components here (scoped per page).
 * - The AI Panel owns the CopilotKit provider. When its core exists it calls
 *   bridge.attachCore(core), and every registration is replayed into that core.
 * - Nothing React ever crosses this boundary. Components are `mount()` functions.
 *
 * Only a *type* import from @copilotkit/core is used, so no CopilotKit or React
 * code is bundled into this package.
 */
import type { CopilotKitCore } from "@copilotkit/core";

/** Any Standard Schema (zod 3.24+/4, valibot, arktype...). Works across zod versions. */
export type Schema = { "~standard": unknown };

export interface ContextDef { description: string; value: unknown }
export interface ToolDef {
  name: string;
  description?: string;
  parameters?: Schema;
  handler: (args: any) => unknown | Promise<unknown>;
}
export interface ComponentDef {
  name: string;
  description?: string;
  parameters: Schema;
  /** Render with the *registering app's own* React. Return an unmount function. */
  mount: (el: HTMLElement, args: any) => () => void;
}

type Off = () => void;
type Entry =
  | { scope: string; kind: "context"; def: ContextDef; applied?: string }
  | { scope: string; kind: "tool"; def: ToolDef; applied?: string };

const asText = (v: unknown) => (typeof v === "string" ? v : JSON.stringify(v ?? null));

class Bridge {
  private core: CopilotKitCore | null = null;
  private entries = new Set<Entry>();
  readonly components = new Map<string, ComponentDef>();
  private listeners = new Set<() => void>();

  /** Called by the AI Panel once its CopilotKit provider has created the core. */
  attachCore(core: CopilotKitCore): Off {
    if (this.core === core) return () => {};
    this.detachCore();
    this.core = core;
    this.entries.forEach((e) => this.apply(e));
    return () => { if (this.core === core) this.detachCore(); };
  }
  private detachCore() {
    this.entries.forEach((e) => this.unapply(e));
    this.core = null;
  }

  private apply(e: Entry) {
    const core = this.core;
    if (!core || e.applied) return;
    if (e.kind === "context") {
      e.applied = core.addContext({ description: e.def.description, value: asText(e.def.value) });
    } else {
      const d = e.def;
      core.addTool({
        name: d.name,
        description: d.description,
        parameters: d.parameters as any,
        handler: async (args: any) => asText(await d.handler(args)),
      });
      e.applied = d.name;
    }
  }
  private unapply(e: Entry) {
    const core = this.core;
    if (core && e.applied) {
      if (e.kind === "context") core.removeContext(e.applied);
      else core.removeTool(e.applied);
    }
    e.applied = undefined;
  }
  private add(e: Entry): Off {
    this.entries.add(e);
    this.apply(e);
    return () => { this.unapply(e); this.entries.delete(e); };
  }

  registerContext(scope: string, def: ContextDef): Off {
    return this.add({ scope, kind: "context", def });
  }
  registerTool(scope: string, def: ToolDef): Off {
    return this.add({ scope, kind: "tool", def });
  }
  /** A component is a tool the model can call. The AI Panel renders it via mount(). */
  registerComponent(scope: string, def: ComponentDef): Off {
    this.components.set(def.name, def);
    this.emit();
    const offTool = this.registerTool(scope, {
      name: def.name,
      description: def.description,
      parameters: def.parameters,
      handler: () => "The component was displayed to the user.",
    });
    return () => { offTool(); this.components.delete(def.name); this.emit(); };
  }
  /** Backstop on page switch: drop everything a scope registered. */
  clearScope(scope: string) {
    for (const e of [...this.entries]) {
      if (e.scope !== scope) continue;
      this.unapply(e);
      this.entries.delete(e);
      if (e.kind === "tool") this.components.delete(e.def.name);
    }
    this.emit();
  }
  /** For debugging UIs: what is registered right now. */
  snapshot() {
    return [...this.entries].map((e) => ({
      scope: e.scope,
      kind: e.kind,
      name: e.kind === "tool" ? e.def.name : e.def.description,
    }));
  }
  subscribe(fn: () => void): Off { this.listeners.add(fn); return () => { this.listeners.delete(fn); }; }
  private emit() { this.listeners.forEach((f) => f()); }
}

// Module Federation shares one copy. The Symbol.for guard is a safety net if it ever loads twice.
const KEY = Symbol.for("acme.copilot.bridge.v1");
export const bridge: Bridge = ((globalThis as any)[KEY] ??= new Bridge());
export type { Bridge };
