import { createRoot } from "react-dom/client"; // Content UI's own react-dom
import { z } from "zod";
import type { ComponentDef } from "@acme/copilot-bridge";
import { inventory, orders, useStore } from "./store";

const box = { border: "1px solid #2d7a5f", background: "#e1f1ea", color: "#1b2430", borderRadius: 8, padding: 12, margin: "6px 0", fontFamily: "system-ui", fontSize: 14 } as const;

function OrderCard({ orderId }: { orderId: string }) {
  const { list } = useStore(orders);
  const o = list.find((x) => x.id === orderId);
  if (!o) return <div style={box}>Order {orderId} not found</div>;
  return (
    <div style={box}>
      <b>{o.id}</b> · {o.customer}<br />
      Total ${o.total.toFixed(2)} · status: <b>{o.status}</b>
      <div style={{ fontSize: 11, opacity: 0.7, marginTop: 4 }}>rendered by Content UI's React</div>
    </div>
  );
}
function StockBars({ skus }: { skus?: string[] }) {
  const { items } = useStore(inventory);
  const rows = skus?.length ? items.filter((i) => skus.includes(i.sku)) : items;
  return (
    <div style={box}>
      {rows.map((i) => (
        <div key={i.sku} style={{ display: "flex", alignItems: "center", gap: 8, margin: "3px 0" }}>
          <span style={{ width: 90 }}>{i.name}</span>
          <div style={{ flex: 1, background: "#fff", height: 10, borderRadius: 5 }}>
            <div style={{ width: `${Math.min(100, i.stock)}%`, height: 10, borderRadius: 5, background: i.stock < i.reorderAt ? "#a3322b" : "#2d7a5f" }} />
          </div>
          <span>{i.stock}</span>
        </div>
      ))}
    </div>
  );
}

/** Turn any React component into a framework-neutral mount() the AI Panel can call. */
function makeMount(Comp: (p: any) => React.ReactElement): ComponentDef["mount"] {
  return (el, args) => {
    const root = createRoot(el);
    root.render(<Comp {...args} />);
    return () => { queueMicrotask(() => root.unmount()); };
  };
}

export const showOrderCard: ComponentDef = {
  name: "show_order_card",
  description: "Show a card for one order in the chat. Use this when the user asks to see an order.",
  parameters: z.object({ orderId: z.string().describe("Order id such as A-1001") }),
  mount: makeMount(OrderCard),
};
export const showStockBars: ComponentDef = {
  name: "show_stock_bars",
  description: "Show a bar chart of stock levels in the chat. Optionally filter by SKUs.",
  parameters: z.object({ skus: z.array(z.string()).optional() }),
  mount: makeMount(StockBars),
};
