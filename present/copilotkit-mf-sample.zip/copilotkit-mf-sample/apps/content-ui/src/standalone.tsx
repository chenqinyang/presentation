// Lets you open http://localhost:3001 on its own (no Host, so no AI Panel attached).
import { mount } from "./mount";
mount(document.getElementById("root")!, { page: "orders" });
