import { createRoot } from "react-dom/client";
import { version } from "react";
import { InventoryPage, OrdersPage } from "./pages";
import "./styles.css";

export type ContentProps = { page: string };

function Content({ page }: ContentProps) {
  return (
    <div className="content">
      <span className="ver">Content UI · React {version}</span>
      {page === "inventory" ? <InventoryPage /> : <OrdersPage />}
    </div>
  );
}

/** The contract with the Host: plain function, own React root, returns an unmount function. */
export function mount(el: HTMLElement, props: ContentProps): () => void {
  const root = createRoot(el);
  root.render(<Content {...props} />);
  return () => { queueMicrotask(() => root.unmount()); };
}
