import { useSyncExternalStore } from "react";

/** Tiny external store so a component mounted in ANOTHER React root (the AI Panel) stays live. */
export function createStore<T>(initial: T) {
  let state = initial;
  const subs = new Set<() => void>();
  return {
    get: () => state,
    set: (f: (s: T) => T) => { state = f(state); subs.forEach((s) => s()); },
    subscribe: (fn: () => void) => { subs.add(fn); return () => { subs.delete(fn); }; },
  };
}
export type Store<T> = ReturnType<typeof createStore<T>>;
export const useStore = <T,>(s: Store<T>) => useSyncExternalStore(s.subscribe, s.get);

export type Order = { id: string; customer: string; total: number; status: "new" | "paid" | "shipped" | "cancelled" };
export type Item = { sku: string; name: string; stock: number; reorderAt: number };

export const orders = createStore<{ list: Order[]; selected: string | null }>({
  selected: null,
  list: [
    { id: "A-1001", customer: "Ada Lovelace", total: 129.5, status: "new" },
    { id: "A-1002", customer: "Alan Turing", total: 58, status: "paid" },
    { id: "A-1003", customer: "Grace Hopper", total: 310.2, status: "shipped" },
    { id: "A-1004", customer: "Linus Torvalds", total: 24.9, status: "new" },
  ],
});
export const inventory = createStore<{ items: Item[] }>({
  items: [
    { sku: "KB-01", name: "Keyboard", stock: 42, reorderAt: 20 },
    { sku: "MS-02", name: "Mouse", stock: 8, reorderAt: 15 },
    { sku: "MN-03", name: "Monitor", stock: 3, reorderAt: 5 },
    { sku: "CB-04", name: "USB-C cable", stock: 120, reorderAt: 50 },
  ],
});
