import { useEffect } from "react"; // Content UI's own React (19.2.8)
import { bridge, type ComponentDef, type ToolDef } from "@acme/copilot-bridge";

/** Registers on mount, re-registers when value changes, unregisters on unmount. */
export function useBridgeContext(scope: string, description: string, value: unknown) {
  const json = JSON.stringify(value);
  useEffect(() => bridge.registerContext(scope, { description, value: json }), [scope, description, json]);
}
export function useBridgeTool(scope: string, tool: ToolDef) {
  useEffect(() => bridge.registerTool(scope, tool), [scope, tool.name]); // eslint-disable-line react-hooks/exhaustive-deps
}
export function useBridgeComponent(scope: string, def: ComponentDef) {
  useEffect(() => bridge.registerComponent(scope, def), [scope, def.name]); // eslint-disable-line react-hooks/exhaustive-deps
}
