import { z } from "zod";
import { orders, inventory, useStore } from "./store";
import { useBridgeComponent, useBridgeContext, useBridgeTool } from "./useBridge";
import { showOrderCard, showStockBars } from "./cards";

export function OrdersPage() {
  const scope = "orders";
  const { list, selected } = useStore(orders);

  // 1) CONTEXT: what the user is looking at right now
  useBridgeContext(scope, "Orders page: the visible orders and the one the user selected", { orders: list, selectedOrderId: selected });

  // 2) TOOLS: read + write
  useBridgeTool(scope, {
    name: "update_order_status",
    description: "Change the status of an order.",
    parameters: z.object({ orderId: z.string(), status: z.enum(["new", "paid", "shipped", "cancelled"]) }),
    handler: ({ orderId, status }: { orderId: string; status: "new" | "paid" | "shipped" | "cancelled" }) => {
      if (!orders.get().list.some((o) => o.id === orderId)) return `No order ${orderId}`;
      orders.set((s) => ({ ...s, list: s.list.map((o) => (o.id === orderId ? { ...o, status } : o)) }));
      return `Order ${orderId} is now ${status}`;
    },
  });

  // 3) COMPONENT: UI the model can show in the chat
  useBridgeComponent(scope, showOrderCard);

  return (
    <div>
      <h2>Orders <small>(Content UI)</small></h2>
      <table>
        <thead><tr><th>ID</th><th>Customer</th><th>Total</th><th>Status</th></tr></thead>
        <tbody>
          {list.map((o) => (
            <tr key={o.id} className={o.id === selected ? "sel" : ""} onClick={() => orders.set((s) => ({ ...s, selected: o.id }))}>
              <td>{o.id}</td><td>{o.customer}</td><td>${o.total.toFixed(2)}</td><td>{o.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <p className="hint">Click a row to select it, then ask the assistant: "mark the selected order as shipped" or "show me order A-1002".</p>
    </div>
  );
}

export function InventoryPage() {
  const scope = "inventory";
  const { items } = useStore(inventory);

  useBridgeContext(scope, "Inventory page: stock levels and reorder thresholds", items);
  useBridgeTool(scope, {
    name: "adjust_stock",
    description: "Add (positive) or remove (negative) units of a SKU.",
    parameters: z.object({ sku: z.string(), delta: z.number() }),
    handler: ({ sku, delta }: { sku: string; delta: number }) => {
      const it = inventory.get().items.find((i) => i.sku === sku);
      if (!it) return `No SKU ${sku}`;
      inventory.set((s) => ({ items: s.items.map((i) => (i.sku === sku ? { ...i, stock: Math.max(0, i.stock + delta) } : i)) }));
      return `${sku} stock is now ${Math.max(0, it.stock + delta)}`;
    },
  });
  useBridgeComponent(scope, showStockBars);

  return (
    <div>
      <h2>Inventory <small>(Content UI)</small></h2>
      <table>
        <thead><tr><th>SKU</th><th>Name</th><th>Stock</th><th>Reorder at</th></tr></thead>
        <tbody>
          {items.map((i) => (
            <tr key={i.sku} className={i.stock < i.reorderAt ? "low" : ""}>
              <td>{i.sku}</td><td>{i.name}</td><td>{i.stock}</td><td>{i.reorderAt}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <p className="hint">Try: "which items are below the reorder level?" then "add 20 mice and show the stock chart".</p>
    </div>
  );
}
