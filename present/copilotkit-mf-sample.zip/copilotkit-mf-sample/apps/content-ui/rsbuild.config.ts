import path from "node:path";
import { defineConfig } from "@rsbuild/core";
import { pluginReact } from "@rsbuild/plugin-react";
import { pluginModuleFederation } from "@module-federation/rsbuild-plugin";

export default defineConfig({
  plugins: [
    pluginReact(),
    pluginModuleFederation({
      name: "content_ui",
      exposes: { "./mount": "./src/mount.tsx" },
      shared: { "@acme/copilot-bridge": { singleton: true, requiredVersion: "^1.0.0" } },
      dts: false,
    }),
  ],
  source: { include: [path.resolve(__dirname, "../../packages")] },
  server: { port: 3001, headers: { "Access-Control-Allow-Origin": "*" } },
  dev: { assetPrefix: "http://localhost:3001" },
});
