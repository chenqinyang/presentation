declare module "content_ui/mount" {
  export function mount(el: HTMLElement, props: { page: string }): () => void;
}
declare module "ai_panel/mount" {
  export function mount(el: HTMLElement, props?: { runtimeUrl?: string }): () => void;
}
