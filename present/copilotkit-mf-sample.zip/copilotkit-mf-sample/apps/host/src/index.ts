// Async boundary: required so Module Federation can negotiate shared modules first.
import("./bootstrap");
export {};
