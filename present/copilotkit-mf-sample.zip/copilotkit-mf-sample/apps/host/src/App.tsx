import { useEffect, useRef, useState } from "react";
import { version } from "react";
import { bridge } from "@acme/copilot-bridge";

const PAGES = [
  { id: "orders", label: "Orders" },
  { id: "inventory", label: "Inventory" },
];

/** Loads a remote's mount() into a div. The remote renders with ITS OWN React. */
function Slot({ load, deps, scope }: { load: () => Promise<(el: HTMLElement) => () => void>; deps: unknown[]; scope?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    let off: (() => void) | undefined;
    let cancelled = false;
    load().then((mount) => { if (!cancelled && ref.current) off = mount(ref.current); });
    return () => {
      cancelled = true;
      off?.();
      if (scope) bridge.clearScope(scope); // backstop: drop whatever the old page registered
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
  return <div ref={ref} className="slot" />;
}

function Registry() {
  const [rows, setRows] = useState(bridge.snapshot());
  useEffect(() => {
    const t = setInterval(() => setRows(bridge.snapshot()), 500);
    return () => clearInterval(t);
  }, []);
  return (
    <footer className="registry">
      <b>Bridge registry</b>
      {rows.length === 0 ? " (empty)" : rows.map((r, i) => <span key={i} className={`chip ${r.kind}`}>{r.kind}: {r.name}</span>)}
    </footer>
  );
}

export function App() {
  const [page, setPage] = useState("orders");
  return (
    <div className="shell">
      <header>
        <strong>Host UI</strong>
        <span className="ver">React {version}</span>
        <nav>
          {PAGES.map((p) => (
            <button key={p.id} className={p.id === page ? "on" : ""} onClick={() => setPage(p.id)}>{p.label}</button>
          ))}
        </nav>
      </header>
      <main>
        <section className="left">
          <Slot
            scope={page}
            deps={[page]}
            load={async () => {
              const m = await import("content_ui/mount");
              return (el) => m.mount(el, { page });
            }}
          />
        </section>
        <aside className="right">
          {/* Never re-created on menu change: deps is empty, so the AI Panel stays mounted. */}
          <Slot
            deps={[]}
            load={async () => {
              const m = await import("ai_panel/mount");
              return (el) => m.mount(el, { runtimeUrl: "http://localhost:4000/api/copilotkit" });
            }}
          />
        </aside>
      </main>
      <Registry />
    </div>
  );
}
