import path from "node:path";
import { defineConfig } from "@rsbuild/core";
import { pluginReact } from "@rsbuild/plugin-react";
import { pluginModuleFederation } from "@module-federation/rsbuild-plugin";

export default defineConfig({
  plugins: [
    pluginReact(),
    pluginModuleFederation({
      name: "host",
      remotes: {
        content_ui: "content_ui@http://localhost:3001/mf-manifest.json",
        ai_panel: "ai_panel@http://localhost:3002/mf-manifest.json",
      },
      // Only the React-free bridge is shared. React is NOT shared: every app keeps its own copy.
      shared: { "@acme/copilot-bridge": { singleton: true, requiredVersion: "^1.0.0" } },
      dts: false,
    }),
  ],
  source: { include: [path.resolve(__dirname, "../../packages")] },
  server: { port: 3000 },
});
