import { useEffect, useRef } from "react";
import { createRoot } from "react-dom/client";
import { version } from "react";
import { CopilotChat, CopilotKitProvider, useCopilotKit } from "@copilotkit/react-core/v2";
import "@copilotkit/react-core/v2/styles.css";
import { bridge } from "@acme/copilot-bridge";
import "./styles.css";

/** Calls the registering app's mount() into a div. The component renders with ITS React, not ours. */
function MountedComponent({ name, args }: { name: string; args: unknown }) {
  const ref = useRef<HTMLDivElement>(null);
  const key = JSON.stringify(args);
  useEffect(() => {
    const def = bridge.components.get(name);
    if (!def || !ref.current) return;
    return def.mount(ref.current, args);
  }, [name, key]); // eslint-disable-line react-hooks/exhaustive-deps
  return <div ref={ref} />;
}

/** Wildcard renderer: any tool call whose name is a registered component gets mounted. */
const componentRenderer = {
  name: "*",
  render: ({ name, args }: { name: string; args: unknown }) =>
    bridge.components.has(name) ? <MountedComponent name={name} args={args} /> : null,
};

/** Hands this panel's CopilotKit core to the bridge so registrations flow into it. */
function BridgeLink() {
  const { copilotkit } = useCopilotKit();
  useEffect(() => bridge.attachCore(copilotkit), [copilotkit]);
  return null;
}

function Panel({ runtimeUrl }: { runtimeUrl: string }) {
  return (
    <CopilotKitProvider runtimeUrl={runtimeUrl} renderToolCalls={[componentRenderer as any]}>
      <BridgeLink />
      <div className="panel">
        <div className="bar">AI Panel <span className="ver">React {version}</span></div>
        <div className="chat"><CopilotChat /></div>
      </div>
    </CopilotKitProvider>
  );
}

export type PanelProps = { runtimeUrl?: string };

export function mount(el: HTMLElement, props: PanelProps = {}): () => void {
  const root = createRoot(el);
  root.render(<Panel runtimeUrl={props.runtimeUrl ?? "http://localhost:4000/api/copilotkit"} />);
  return () => { queueMicrotask(() => root.unmount()); };
}
