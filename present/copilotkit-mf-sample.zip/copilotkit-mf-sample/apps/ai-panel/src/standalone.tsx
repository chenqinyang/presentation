import { mount } from "./mount";
const el = document.getElementById("root")!;
el.style.height = "100vh";
mount(el, {});
