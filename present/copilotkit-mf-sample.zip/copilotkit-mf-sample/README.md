# CopilotKit v2 + Rsbuild Module Federation, three different React versions

| App | Port | React | Role |
|---|---|---|---|
| `apps/host` | 3000 | 19.3.1 | Shell and menu. Loads the other two as remotes. |
| `apps/content-ui` | 3001 | 19.2.8 | Left side. Registers context, tools and components. |
| `apps/ai-panel` | 3002 | 19.2.9 | Right side. Owns the CopilotKit provider and chat. Stays mounted across menu changes. |
| `server` | 4000 | none | CopilotKit runtime that calls DeepSeek. Your API key lives here only. |
| `packages/copilot-bridge` | none | none | React-free singleton shared via Module Federation. |

React is **not** shared. Only `@acme/copilot-bridge` is, as a singleton.

## Run it (Node 20+)

```bash
npm install
cp server/.env.example server/.env     # then paste your DeepSeek key into server/.env
npm run dev
```

Open http://localhost:3000. The header chips show each app's React version.
The footer shows what is registered in the bridge, and it changes when you switch menu.

## Things to try

Orders page (click a row first):
- "Mark the selected order as shipped"
- "Show me order A-1002" (renders a card built by Content UI's React inside the chat)

Inventory page:
- "Which items are below the reorder level?"
- "Add 20 mice, then show the stock chart"

## How it works

1. `content-ui/src/pages.tsx` calls `useBridgeContext/Tool/Component(scope, ...)`. These are thin `useEffect` wrappers around `bridge.register*` and they unregister on unmount.
2. `ai-panel/src/mount.tsx` renders `<CopilotKitProvider>` plus `BridgeLink`, which calls `bridge.attachCore(copilotkit)`. The bridge replays every registration into that core with `core.addContext` / `core.addTool`.
3. A component is a tool the model can call. The panel's wildcard `renderToolCalls` entry finds it in `bridge.components` and calls its `mount(el, args)`. It renders in Content UI's own React root, so no hook runs under the wrong React.
4. On menu change the Host unmounts the old page (cleanups fire) and calls `bridge.clearScope(page)` as a backstop. The AI Panel is untouched.
5. Parameters use zod in Content UI and cross the bridge as Standard Schema objects, so zod versions don't need to match anything else.

## Notes

- Model defaults to `deepseek-chat`. Change `DEEPSEEK_MODEL` in `server/.env`. `deepseek-reasoner` is slower and may not support tool calling.
- The key is read only by `server/index.mjs` and never reaches the browser.
- Production: pin remote URLs in `apps/host/rsbuild.config.ts`, set `output.assetPrefix` for each remote, and restrict CORS on the server.
