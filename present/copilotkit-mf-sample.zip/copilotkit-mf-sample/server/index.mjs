import "dotenv/config";
import express from "express";
import { createDeepSeek } from "@ai-sdk/deepseek";
import { CopilotRuntime, BuiltInAgent, createCopilotEndpointExpress } from "@copilotkit/runtime/v2";

const apiKey = process.env.DEEPSEEK_API_KEY;
if (!apiKey) {
  console.error("\n[server] DEEPSEEK_API_KEY is missing. Copy server/.env.example to server/.env and set it.\n");
  process.exit(1);
}

const deepseek = createDeepSeek({ apiKey }); // https://api.deepseek.com
const modelId = process.env.DEEPSEEK_MODEL || "deepseek-chat";

const agent = new BuiltInAgent({
  model: deepseek(modelId),
  maxSteps: 6, // allow: call tool -> read result -> answer
  prompt:
    "You are the assistant in a business app. The user is looking at a page on the left. " +
    "Use the provided context to understand what they see. " +
    "Use the available tools to read or change data, and call display tools to show results as UI. " +
    "Be concise.",
});

const runtime = new CopilotRuntime({ agents: { default: agent } });

const app = express();
app.use(createCopilotEndpointExpress({ runtime, basePath: "/api/copilotkit" })); // CORS is permissive by default
app.get("/health", (_req, res) => res.json({ ok: true, model: modelId }));

const port = Number(process.env.PORT || 4000);
app.listen(port, () => console.log(`[server] CopilotKit runtime on http://localhost:${port}/api/copilotkit (model: ${modelId})`));
