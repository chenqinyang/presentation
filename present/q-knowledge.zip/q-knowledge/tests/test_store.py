import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
from qknowledge import Store, chunks, Embedder

class KnowledgeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name)/'test.sqlite3'
        self.s = Store(self.path)
        self.s.create_base('engineering','Engineering','Software design')
        self.s.create_base('operations','Operations','Company processes')
    def tearDown(self):
        self.s.db.close()
        self.tmp.cleanup()
    def add(self,body='Deployments use exponential retries with jitter.',bases=('engineering',),**kw):
        return self.s.ingest('Retry policy',body,'Deployment retry rules','user-message:test',bases,**kw)['id']
    def cli(self,*args):
        return subprocess.run([sys.executable,str(Path(__file__).resolve().parents[1]/'qknowledge.py'),'--db',str(self.path),*args],capture_output=True,text=True)
    def test_persistence_counts(self):
        self.add()
        self.s.db.close()
        self.s = Store(self.path)
        o = self.s.overview()
        self.assertEqual((o['knowledge_base_count'],o['document_count'],o['knowledge_bases'][0]['items']),(2,1,1))
    def test_pending_resolution(self):
        doc = self.add(bases=(),question='Where?')
        self.assertEqual(self.s.overview()['pending'][0]['id'],doc)
        self.assertEqual(self.s.search('retries')['results'],[])
        self.assertTrue(self.s.search('retries',include_pending=True)['results'])
        self.s.assign(doc,['operations'])
        self.assertEqual(self.s.overview()['pending'],[])
        self.assertEqual(self.s.search('retries','operations')['results'][0]['document_id'],doc)
    def test_duplicate_multibase(self):
        doc = self.add()
        r = self.s.ingest('Other title','Deployments use exponential retries with jitter.','Summary','other-source',['operations'])
        self.assertTrue(r['duplicate'])
        self.assertEqual(r['id'],doc)
        self.assertEqual(self.s.overview()['document_count'],1)
        self.assertEqual(len(self.s.show(doc)['sources']),2)
        self.assertEqual(self.s.show(doc)['knowledge_bases'],['engineering','operations'])
    def test_search_scope_citation(self):
        doc = self.add()
        self.add('Supplier onboarding requires approval.',('operations',))
        r = self.s.search('exponential retries','engineering')['results'][0]
        self.assertEqual(r['document_id'],doc)
        self.assertEqual(r['citation'],f'[K{doc}:C0]')
        self.assertEqual(r['sources'][0]['source'],'user-message:test')
        self.assertTrue(all(r['knowledge_bases']==['operations'] for r in self.s.search('approval','operations')['results']))
    def test_unknown_base_atomic(self):
        with self.assertRaises(ValueError): self.add(bases=('missing',))
        self.assertEqual(self.s.overview()['document_count'],0)
    def test_assign_replace(self):
        doc = self.add()
        with self.assertRaises(ValueError): self.s.assign(doc,['missing'],True)
        self.assertEqual(self.s.show(doc)['knowledge_bases'],['engineering'])
        self.s.assign(doc,['operations'],True)
        self.assertEqual(self.s.show(doc)['knowledge_bases'],['operations'])
    def test_supersession(self):
        old = self.add()
        new = self.add('At most three retries.',supersedes=old)
        self.assertEqual(self.s.show(old)['superseded_by'],[new])
        self.assertIn('exponential',self.s.show(old)['body'])
    def test_bad_supersession_atomic(self):
        with self.assertRaises(sqlite3.IntegrityError): self.add(supersedes=999)
        self.assertEqual(self.s.overview()['document_count'],0)
        self.assertEqual(self.s.db.execute('SELECT count(*) FROM chunks_fts').fetchone()[0],0)
    def test_unicode_and_query_syntax(self):
        body = '中文知识库与软件部署。'*180
        doc = self.add(body)
        self.assertEqual(self.s.show(doc)['body'],body)
        self.assertEqual(''.join(p[:500] for p in chunks(body)),body)
        self.assertTrue(all(len(p)<=600 for p in chunks(body)))
        self.assertTrue(self.s.search('中文部署')['results'])
        self.s.search('"* OR : () --')
    def test_failed_reindex_atomic(self):
        self.add()
        before = self.s.db.execute('SELECT vector FROM chunks').fetchone()[0]
        with patch('qknowledge.Embedder.encode',side_effect=[[[1.0]], RuntimeError('model failed')]):
            with self.assertRaises(RuntimeError): self.s.reindex('sentence-transformers','fake')
        self.assertEqual(self.s.settings()['provider'],'hash')
        self.assertEqual(self.s.db.execute('SELECT vector FROM chunks').fetchone()[0],before)
        self.assertTrue(self.s.search('retries')['results'])
    def test_provider_switch(self):
        self.add()
        with patch('qknowledge.Embedder.encode',side_effect=lambda texts:[[1.0,0.0] for _ in texts]):
            self.s.reindex('sentence-transformers','test-model')
            self.assertEqual(self.s.settings()['model'],'test-model')
            self.assertTrue(self.s.search('test')['results'])
        self.s.reindex('hash','hash-v1-512')
        self.assertTrue(self.s.search('retries')['results'])
    def test_backup_export_rules(self):
        self.add()
        p = self.cli('rule-add','--kb','engineering','--instruction','Retry policies belong here.')
        self.assertEqual(p.returncode,0,p.stderr)
        backup = Path(self.tmp.name)/'backup.sqlite3'
        p = self.cli('backup',str(backup))
        self.assertEqual(p.returncode,0,p.stderr)
        restored = Store(backup)
        try:
            self.assertEqual(restored.overview()['document_count'],1)
            self.assertEqual(len(restored.rules()),1)
            self.assertTrue(restored.search('retries')['results'])
        finally: restored.db.close()
        self.assertNotEqual(self.cli('backup',str(backup)).returncode,0)
        export = Path(self.tmp.name)/'export.json'
        self.assertEqual(self.cli('export',str(export)).returncode,0)
        self.assertEqual(len(json.loads(export.read_text())['documents']),1)
        self.assertEqual(self.cli('rule-delete','1').returncode,0)
        self.assertEqual(self.s.rules(),[])
    def test_cli_ingest_update_errors(self):
        note = Path(self.tmp.name)/'note.md'
        note.write_text('Support hours are Monday to Friday.',encoding='utf-8')
        p = self.cli('ingest','--file',str(note),'--title','Support','--summary','Weekday support','--source','manual','--kb','operations')
        self.assertEqual(p.returncode,0,p.stderr)
        self.assertEqual(self.cli('kb-update','operations','--purpose','Business operations').returncode,0)
        self.assertEqual(self.s.overview()['knowledge_bases'][1]['purpose'],'Business operations')
        p = self.cli('show','999')
        self.assertNotEqual(p.returncode,0)
        self.assertIn('error',json.loads(p.stderr))
    def test_search_snapshot_during_reindex(self):
        self.add()
        encode = Embedder.encode
        def concurrent_change(encoder, texts):
            result = encode(encoder, texts)
            other = Store(self.path)
            try:
                with patch('qknowledge.Embedder.encode', side_effect=lambda batch: [[1.0,0.0] for _ in batch]):
                    other.reindex('sentence-transformers','concurrent-model')
            finally:
                other.db.close()
            return result
        with patch('qknowledge.Embedder.encode', new=concurrent_change):
            result = self.s.search('retries')
        self.assertTrue(result['results'])
        self.assertEqual(result['embedding']['provider'],'hash')
        self.assertEqual(self.s.settings()['model'],'concurrent-model')

    def test_unknown_schema(self):
        self.s.db.execute('PRAGMA user_version=9')
        with self.assertRaises(ValueError): Store(self.path)

if __name__ == '__main__': unittest.main()
