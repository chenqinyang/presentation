# q-knowledge

A local knowledge workspace for GitHub Copilot and OpenCode. Tell the agent what
to remember or ask questions naturally. The agent organizes and reasons; a Python
CLI saves knowledge, categories, preferences, sources, and pending questions in
SQLite so new chats can recover the same memory.

## Start

Requires Python 3.10+ with SQLite FTS5. No API key or database service is required.
Open **this folder** as the workspace in Copilot agent mode, or start OpenCode here.

```sh
python3 qknowledge.py init
python3 qknowledge.py overview
```

Then try:

- “Create knowledge bases for engineering, product research, and company operations. Ask me if their scopes need clarification.”
- “Remember this deployment checklist in engineering: …”
- “Save this information and choose the appropriate knowledge base: …”
- “Which knowledge bases do I have, and what kinds of knowledge do they contain?”
- “What does my engineering knowledge say about deployment retries? Cite the sources.”
- “Show items waiting for my categorization advice.”
- “From now on, supplier onboarding goes in operations.”

No knowledge bases or sample personal knowledge are preloaded. The first ambiguous
input is saved to a persistent inbox and the agent asks where it belongs. A record
can belong to multiple bases without duplicating its content.

## Agent discovery

The shared skill is `.agents/skills/q-knowledge/SKILL.md`, a location supported by
[GitHub Copilot](https://docs.github.com/en/copilot/how-tos/copilot-on-github/customize-copilot/customize-cloud-agent/add-skills)
and [OpenCode](https://docs.opencode.ai/docs/skills/). Root `AGENTS.md` supplies
OpenCode's project instructions, and `.github/copilot-instructions.md` supplies
Copilot's repository instructions. Both instruct the agent to read the skill for
knowledge tasks, so you do not need to invoke it manually. Skills themselves are
loaded on demand; client settings and tool permissions still control execution.
Use an agent-capable mode with file and terminal access, and enable repository
instructions if your client has disabled them. This is project-local setup, not
an installation into every workspace on your machine.

## SQLite vector search

SQLite stores documents, provenance, memberships, rules, audit events, chunk
vectors, and an FTS5 text index. Search combines vector ranking and keyword ranking
using reciprocal rank fusion. Vectors are normalized JSON arrays in SQLite;
a registered SQLite function computes exact dot-product/cosine scores. There is
no separate vector service or native extension. This is an exhaustive scan,
suitable for a small or medium personal collection, not an ANN index for millions
of chunks. Search returns chunk text, IDs, sources, and replacement pointers;
the agent reads full records and writes the answer.

Two embedding modes are available:

| Mode | Setup | Capability |
| --- | --- | --- |
| `hash` (initial) | Python standard library only | Offline hashed token vectors plus FTS5; lexical similarity, **not semantic understanding**. |
| `sentence-transformers` | Optional Python packages and initial model download | Local semantic embeddings, including multilingual retrieval with the default model. |

For meaning-based search, enable the recommended semantic mode:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements-semantic.txt
.venv/bin/python qknowledge.py reindex --provider sentence-transformers
.venv/bin/python qknowledge.py search 'What do we know about reliable deployments?'
```

The default model is `sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2`.
The initial setup downloads third-party packages and model weights; document text
is embedded locally. Later runs need the cached model. Package installation can
be substantial because of PyTorch. See the
[Sentence Transformers documentation](https://sbert.net/docs/quickstart.html).
This project's delivered tests validate the offline path and provider consistency;
the optional real model requires installation and a retrieval check in your environment.

Use `--model MODEL_OR_LOCAL_PATH` with `reindex` to select another compatible dense
Sentence Transformer. Models needing custom query prompts or special encoding
APIs are not configured by this adapter. Changing a model re-embeds every chunk
atomically. Failure preserves the previous index. Keep using the same virtual
environment for subsequent commands. To return to offline lexical vectors:

```sh
python3 qknowledge.py reindex --provider hash
```

## Commands

All commands produce JSON. Run `python3 qknowledge.py COMMAND --help` for arguments.
`--db PATH`, placed before the command, selects a separate database; otherwise the
path is anchored to the script directory, even if called from another directory.

| Command | Purpose |
| --- | --- |
| `init` | Create an empty persistent store, idempotently |
| `kb-create SLUG --name NAME --purpose PURPOSE` | Create a base; optional `--boundaries` clarifies routing |
| `kb-update SLUG --purpose PURPOSE` | Update purpose, name, or boundaries |
| `overview` | Counts, scopes, recent item summaries, inbox, and preferences |
| `ingest --file FILE --title TITLE --summary SUMMARY --source SOURCE` | Save extracted UTF-8 text; no `--kb` means pending |
| `assign ID --kb SLUG` | Add a base membership; `--replace` replaces all existing memberships |
| `show ID` | Full stored text, provenance, memberships, and supersession links |
| `search QUERY` | Hybrid retrieval; optional `--kb`, `--limit`, `--include-pending` |
| `rule-add --kb SLUG --instruction TEXT` | Persist a user-approved routing preference for the agent |
| `rules` / `rule-delete ID` | Inspect or remove preferences |
| `reindex --provider PROVIDER` | Atomically rebuild all vectors and persist the provider |
| `backup DESTINATION` | Consistent SQLite snapshot, including vectors and audit history |
| `export DESTINATION` | Human-readable JSON inventory and complete source text |

`ingest` accepts repeated `--kb` and `--tag`, `--question` for pending items,
`--supersedes ID` for corrections, and `--file -` for stdin. Summary text is supplied
by the agent, not automatically generated by the CLI. Rules are interpreted by the
agent, not a hidden automatic classifier. Exact trimmed-content duplicates retain
the original record and gain new source/base links. Similar but different records
are preserved. Original source files are not copied; store/backup originals
separately if needed. PDFs, websites, images, and Office files must first be
extracted with the agent's available tools. No web crawler or OCR is included.

High-level overview shows up to eight recent items per base; use export for a full
inventory. Pending records are searchable only with `--include-pending`. Retrieval
scores are ranks, not confidence. Semantic vectors may return related but
non-answering material; the agent must say when evidence is insufficient.

## Backup and portability

```sh
python3 qknowledge.py backup backups/knowledge-2026-11-06.sqlite3
python3 qknowledge.py export work/inventory.json
```

Use a new filename for each backup/export; existing destinations are refused.
Backups are complete databases; JSON exports are readable archives, not an import
format. To restore: stop all agents/CLI writers, keep a backup of the current DB,
then replace `data/knowledge.sqlite3` with the chosen SQLite backup. Do not leave
old `knowledge.sqlite3-wal` or `knowledge.sqlite3-shm` files alongside a restored
DB; remove those only after stopping all connections and preserving the old store.
Run `overview` after restoring, and use the recorded embedding environment.

The default data folder and scratch/backup folders are gitignored. SQLite is not
encrypted. Local Copilot and OpenCode sessions share the same DB; another computer,
remote container, or Copilot cloud agent does not have it automatically. Provision
a backup explicitly when you want another environment to access your knowledge.
Do not concurrently sync the live SQLite files with file-sync tools; transfer
consistent backups. Knowledge retrieved into an AI conversation is subject to
the configured model provider's data handling.

## Development and checks

```sh
python3 -m unittest discover -s tests -v
```

Tests use temporary databases and do not modify your knowledge. The schema is
versioned at v1 and rejects unknown versions. Writes use transactions; ingestion
and reindex serialize writers to keep embedding settings consistent. The skill
asks before choosing an uncertain destination; this conversational behavior is
an instruction to the host agent, not something this standalone CLI can enforce.
