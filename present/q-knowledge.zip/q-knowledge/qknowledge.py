#!/usr/bin/env python3
"""Persistent multi-KB memory. Python 3.10+, SQLite FTS5, optional local embeddings."""
import argparse
import hashlib
import json
import math
import re
import sqlite3
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DEFAULT_MODEL = 'sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2'


def now():
    return datetime.now(timezone.utc).isoformat()


def tokens(text):
    return re.findall(r'[a-z0-9_]+|[\u3400-\u9fff]', text.lower())


def chunks(text, size=600, overlap=100):
    # Character chunks keep CJK and long unbroken input bounded too.
    return [text[i:i + size] for i in range(0, len(text), size - overlap)]


class Embedder:
    def __init__(self, provider='hash', model=DEFAULT_MODEL):
        self.provider, self.model, self.encoder = provider, model, None

    def encode(self, texts):
        if self.provider == 'sentence-transformers':
            if self.encoder is None:
                try:
                    from sentence_transformers import SentenceTransformer
                except ImportError as e:
                    raise ValueError('Install requirements-semantic.txt in your venv first.') from e
                self.encoder = SentenceTransformer(self.model)
            return self.encoder.encode(texts, normalize_embeddings=True).tolist()
        result = []
        for text in texts:
            v = [0.0] * 512
            for word in tokens(text):
                h = int.from_bytes(hashlib.sha256(word.encode()).digest()[:8], 'big')
                v[h % 512] += 1 if (h >> 9) % 2 else -1
            norm = math.sqrt(sum(x*x for x in v)) or 1
            result.append([x / norm for x in v])
        return result


def cosine(raw, query):
    v = json.loads(raw)
    if len(v) != len(query):
        raise ValueError('Embedding dimension mismatch; reindex required.')
    return sum(a*b for a, b in zip(v, query))


class Store:
    def __init__(self, path):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(path, timeout=30)
        self.db.row_factory = sqlite3.Row
        self.db.execute('PRAGMA foreign_keys=ON')
        self.db.execute('PRAGMA journal_mode=WAL')
        version = self.db.execute('PRAGMA user_version').fetchone()[0]
        if version not in (0, 1):
            self.db.close()
            raise ValueError(f'Unsupported database schema {version}')
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS bases(
          slug TEXT PRIMARY KEY, name TEXT NOT NULL, purpose TEXT NOT NULL,
          boundaries TEXT NOT NULL DEFAULT '', created TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS documents(
          id INTEGER PRIMARY KEY, title TEXT NOT NULL, body TEXT NOT NULL,
          summary TEXT NOT NULL, tags TEXT NOT NULL, digest TEXT NOT NULL UNIQUE,
          status TEXT NOT NULL CHECK(status IN ('pending','filed')),
          question TEXT NOT NULL DEFAULT '', supersedes INTEGER REFERENCES documents(id),
          created TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS sources(
          document_id INTEGER NOT NULL REFERENCES documents(id), source TEXT NOT NULL,
          captured TEXT NOT NULL, PRIMARY KEY(document_id,source));
        CREATE TABLE IF NOT EXISTS memberships(
          document_id INTEGER NOT NULL REFERENCES documents(id),
          kb TEXT NOT NULL REFERENCES bases(slug), PRIMARY KEY(document_id,kb));
        CREATE TABLE IF NOT EXISTS chunks(
          id INTEGER PRIMARY KEY, document_id INTEGER NOT NULL REFERENCES documents(id),
          position INTEGER NOT NULL, text TEXT NOT NULL, vector TEXT NOT NULL);
        CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts USING fts5(text);
        CREATE TABLE IF NOT EXISTS rules(
          id INTEGER PRIMARY KEY, instruction TEXT NOT NULL, kb TEXT NOT NULL REFERENCES bases(slug),
          created TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS events(
          id INTEGER PRIMARY KEY, action TEXT NOT NULL, detail TEXT NOT NULL, created TEXT NOT NULL);
        INSERT OR IGNORE INTO settings VALUES('provider','hash');
        INSERT OR IGNORE INTO settings VALUES('model','hash-v1-512');
        PRAGMA user_version=1;
        ''')

    def settings(self):
        return dict(self.db.execute('SELECT key,value FROM settings'))

    def embedder(self):
        s = self.settings()
        return Embedder(s['provider'], s['model'])

    def event(self, action, detail):
        self.db.execute('INSERT INTO events(action,detail,created) VALUES(?,?,?)',
                        (action, json.dumps(detail, ensure_ascii=False), now()))

    def check_bases(self, bases):
        for kb in bases:
            if not self.db.execute('SELECT 1 FROM bases WHERE slug=?', (kb,)).fetchone():
                raise ValueError(f'Unknown knowledge base: {kb}')

    def create_base(self, slug, name, purpose, boundaries=''):
        if not re.fullmatch('[a-z0-9]+(?:-[a-z0-9]+)*', slug):
            raise ValueError('Use a lowercase kebab-case slug.')
        if not name.strip() or not purpose.strip():
            raise ValueError('Name and purpose are required.')
        with self.db:
            self.db.execute('INSERT INTO bases VALUES(?,?,?,?,?)', (slug,name,purpose,boundaries,now()))
            self.event('kb-create', {'slug':slug})
        return {'kb':slug}

    def overview(self):
        bases = []
        for row in self.db.execute('SELECT * FROM bases ORDER BY slug'):
            b = dict(row)
            b['items'] = self.db.execute('SELECT count(*) FROM memberships WHERE kb=?',(b['slug'],)).fetchone()[0]
            b['recent_knowledge'] = [dict(r) for r in self.db.execute('''
              SELECT d.id,d.title,d.summary,d.tags FROM documents d JOIN memberships m
              ON d.id=m.document_id WHERE m.kb=? ORDER BY d.id DESC LIMIT 8''',(b['slug'],))]
            bases.append(b)
        pending = [dict(r) for r in self.db.execute("SELECT id,title,question FROM documents WHERE status='pending' ORDER BY id")]
        return {'knowledge_base_count':len(bases), 'knowledge_bases':bases,
                'document_count':self.db.execute('SELECT count(*) FROM documents').fetchone()[0],
                'pending':pending, 'routing_rules':self.rules(), 'embedding':self.settings()}

    def rules(self):
        return [dict(r) for r in self.db.execute('SELECT * FROM rules ORDER BY id')]

    def ingest(self, title, body, summary, source, bases=(), tags=(), question='', supersedes=None):
        if not body.strip() or not title.strip() or not summary.strip() or not source.strip():
            raise ValueError('Nonempty title, body, summary, and source are required.')
        bases = sorted(set(bases))
        digest = hashlib.sha256(body.strip().encode()).hexdigest()
        # Lock before reading settings: embedding space and inserted vectors stay consistent.
        with self.db:
            self.db.execute('BEGIN IMMEDIATE')
            self.check_bases(bases)
            existing = self.db.execute('SELECT id FROM documents WHERE digest=?',(digest,)).fetchone()
            if existing:
                doc_id = existing[0]
                self.db.execute('INSERT OR IGNORE INTO sources VALUES(?,?,?)',(doc_id,source,now()))
                for kb in bases:
                    self.db.execute('INSERT OR IGNORE INTO memberships VALUES(?,?)',(doc_id,kb))
                if bases:
                    self.db.execute("UPDATE documents SET status='filed',question='' WHERE id=?",(doc_id,))
                self.event('deduplicate',{'id':doc_id,'bases':bases,'source':source})
                return {'id':doc_id, 'duplicate':True, 'document':self.show(doc_id)}
            parts = chunks(body)
            vectors = self.embedder().encode([title+'\n'+part for part in parts])
            cur = self.db.execute('''INSERT INTO documents(title,body,summary,tags,digest,status,question,supersedes,created)
              VALUES(?,?,?,?,?,?,?,?,?)''', (title,body,summary,json.dumps(list(tags)),digest,
              'filed' if bases else 'pending', '' if bases else (question or 'Which knowledge base should contain this?'),supersedes,now()))
            doc_id = cur.lastrowid
            self.db.execute('INSERT INTO sources VALUES(?,?,?)',(doc_id,source,now()))
            for kb in bases:
                self.db.execute('INSERT INTO memberships VALUES(?,?)',(doc_id,kb))
            for i,(part,vector) in enumerate(zip(parts,vectors)):
                c = self.db.execute('INSERT INTO chunks(document_id,position,text,vector) VALUES(?,?,?,?)',
                                    (doc_id,i,part,json.dumps(vector))).lastrowid
                self.db.execute('INSERT INTO chunks_fts(rowid,text) VALUES(?,?)',(c,title+'\n'+part))
            self.event('ingest',{'id':doc_id,'bases':bases})
        return {'id':doc_id,'duplicate':False,'status':'filed' if bases else 'pending','chunks':len(parts)}

    def show(self, doc_id):
        row = self.db.execute('SELECT * FROM documents WHERE id=?',(doc_id,)).fetchone()
        if not row:
            raise ValueError(f'Unknown document: {doc_id}')
        d = dict(row)
        d['tags'] = json.loads(d['tags'])
        d['knowledge_bases'] = [r[0] for r in self.db.execute('SELECT kb FROM memberships WHERE document_id=? ORDER BY kb',(doc_id,))]
        d['sources'] = [dict(r) for r in self.db.execute('SELECT source,captured FROM sources WHERE document_id=?',(doc_id,))]
        d['superseded_by'] = [r[0] for r in self.db.execute('SELECT id FROM documents WHERE supersedes=?',(doc_id,))]
        return d

    def assign(self, doc_id, bases, replace=False):
        self.show(doc_id)
        if not bases:
            raise ValueError('At least one target KB is required.')
        with self.db:
            self.check_bases(bases)
            if replace:
                self.db.execute('DELETE FROM memberships WHERE document_id=?',(doc_id,))
            for kb in set(bases):
                self.db.execute('INSERT OR IGNORE INTO memberships VALUES(?,?)',(doc_id,kb))
            self.db.execute("UPDATE documents SET status='filed',question='' WHERE id=?",(doc_id,))
            self.event('assign',{'id':doc_id,'bases':bases,'replace':replace})
        return self.show(doc_id)

    def search(self, query, kb=None, limit=8, include_pending=False):
        # Hold one read snapshot so concurrent reindex cannot mix embedding spaces.
        with self.db:
            self.db.execute('BEGIN')
            return self._search(query, kb, limit, include_pending)

    def _search(self, query, kb=None, limit=8, include_pending=False):
        if not query.strip() or not 1 <= limit <= 100:
            raise ValueError('Provide a query and limit between 1 and 100.')
        if kb:
            self.check_bases([kb])
        vector = self.embedder().encode([query])[0]
        self.db.create_function('vector_similarity',1,lambda raw:cosine(raw,vector))
        condition = '1=1' if include_pending else "d.status='filed'"
        params = []
        if kb:
            condition += ' AND EXISTS(SELECT 1 FROM memberships m WHERE m.document_id=d.id AND m.kb=?)'
            params.append(kb)
        sql = f'''SELECT c.id AS chunk_id,c.document_id,c.position,c.text,d.title,d.status,
          vector_similarity(c.vector) AS similarity FROM chunks c JOIN documents d ON d.id=c.document_id
          WHERE {condition}'''
        vector_rows = self.db.execute(sql+' ORDER BY similarity DESC,c.id LIMIT 100',params).fetchall()
        terms = list(dict.fromkeys(tokens(query)))[:64]
        lexical = []
        if terms:
            match = ' OR '.join('"'+t+'"' for t in terms)
            lexical = self.db.execute(f'''SELECT c.id FROM chunks_fts f JOIN chunks c ON c.id=f.rowid
              JOIN documents d ON d.id=c.document_id WHERE chunks_fts MATCH ? AND {condition}
              ORDER BY bm25(chunks_fts) LIMIT 100''',[match]+params).fetchall()
        ranks = {}
        for rank,row in enumerate(vector_rows):
            if row['similarity'] > 0:
                ranks[row['chunk_id']] = 1/(60+rank+1)
        for rank,row in enumerate(lexical):
            ranks[row[0]] = ranks.get(row[0],0)+1/(60+rank+1)
        results = []
        for chunk_id, score in sorted(ranks.items(),key=lambda p:(-p[1],p[0]))[:limit]:
            row = self.db.execute(sql+' AND c.id=?',params+[chunk_id]).fetchone()
            r = dict(row)
            doc = self.show(r['document_id'])
            r.update(score=score, sources=doc['sources'], knowledge_bases=doc['knowledge_bases'],
                     superseded_by=doc['superseded_by'], citation=f"[K{r['document_id']}:C{r['position']}]")
            results.append(r)
        return {'query':query,'embedding':self.settings(),'results':results,
                'note':'Scores rank candidates; they are not confidence or proof. Read full documents before answering.'}

    def reindex(self, provider, model):
        embedder = Embedder(provider,model)
        with self.db:
            self.db.execute('BEGIN IMMEDIATE')
            rows = self.db.execute('SELECT c.id,c.text,d.title FROM chunks c JOIN documents d ON d.id=c.document_id ORDER BY c.id').fetchall()
            # Load/verify even for an empty database; errors leave the old index intact.
            embedder.encode(['embedding readiness check'])
            for start in range(0,len(rows),64):
                batch = rows[start:start+64]
                vectors = embedder.encode([r['title']+'\n'+r['text'] for r in batch])
                self.db.executemany('UPDATE chunks SET vector=? WHERE id=?',
                                    [(json.dumps(v),r['id']) for r,v in zip(batch,vectors)])
            self.db.executemany('UPDATE settings SET value=? WHERE key=?',[(provider,'provider'),(model,'model')])
            self.event('reindex',{'provider':provider,'model':model,'chunks':len(rows)})
        return self.settings()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--db',type=Path,default=ROOT/'data'/'knowledge.sqlite3')
    sub = parser.add_subparsers(dest='command',required=True)
    for name in ('init','overview','rules'):
        sub.add_parser(name)
    p = sub.add_parser('kb-create')
    p.add_argument('slug'); p.add_argument('--name',required=True); p.add_argument('--purpose',required=True); p.add_argument('--boundaries',default='')
    p = sub.add_parser('kb-update')
    p.add_argument('slug'); p.add_argument('--name'); p.add_argument('--purpose'); p.add_argument('--boundaries')
    p = sub.add_parser('ingest')
    p.add_argument('--file',type=Path,required=True,help='UTF-8 text/Markdown; use - for stdin')
    p.add_argument('--title',required=True); p.add_argument('--summary',required=True); p.add_argument('--source',required=True)
    p.add_argument('--kb',action='append',default=[]); p.add_argument('--tag',action='append',default=[])
    p.add_argument('--question',default=''); p.add_argument('--supersedes',type=int)
    p = sub.add_parser('show'); p.add_argument('id',type=int)
    p = sub.add_parser('assign'); p.add_argument('id',type=int); p.add_argument('--kb',action='append',required=True); p.add_argument('--replace',action='store_true')
    p = sub.add_parser('search'); p.add_argument('query'); p.add_argument('--kb'); p.add_argument('--limit',type=int,default=8); p.add_argument('--include-pending',action='store_true')
    p = sub.add_parser('rule-add'); p.add_argument('--kb',required=True); p.add_argument('--instruction',required=True)
    p = sub.add_parser('rule-delete'); p.add_argument('id',type=int)
    p = sub.add_parser('reindex'); p.add_argument('--provider',choices=['hash','sentence-transformers'],required=True); p.add_argument('--model',default=DEFAULT_MODEL)
    p = sub.add_parser('backup'); p.add_argument('destination',type=Path)
    p = sub.add_parser('export'); p.add_argument('destination',type=Path)
    args = parser.parse_args()
    store = None
    try:
        store = Store(args.db)
        c = args.command
        if c == 'init': result = {'database':str(args.db.resolve()), **store.settings()}
        elif c == 'overview': result = store.overview()
        elif c == 'rules': result = store.rules()
        elif c == 'kb-create': result = store.create_base(args.slug,args.name,args.purpose,args.boundaries)
        elif c == 'kb-update':
            store.check_bases([args.slug])
            with store.db:
                for field in ('name','purpose','boundaries'):
                    val = getattr(args,field)
                    if val is not None:
                        if field != 'boundaries' and not val.strip(): raise ValueError(f'{field} cannot be empty')
                        store.db.execute(f'UPDATE bases SET {field}=? WHERE slug=?',(val,args.slug))
                store.event(c,{'kb':args.slug})
            result = store.overview()
        elif c == 'ingest':
            body = sys.stdin.read() if str(args.file)=='-' else args.file.read_text(encoding='utf-8')
            result = store.ingest(args.title,body,args.summary,args.source,args.kb,args.tag,args.question,args.supersedes)
        elif c == 'show': result = store.show(args.id)
        elif c == 'assign': result = store.assign(args.id,args.kb,args.replace)
        elif c == 'search': result = store.search(args.query,args.kb,args.limit,args.include_pending)
        elif c == 'rule-add':
            store.check_bases([args.kb])
            if not args.instruction.strip(): raise ValueError('Rule cannot be empty')
            with store.db:
                store.db.execute('INSERT INTO rules(instruction,kb,created) VALUES(?,?,?)',(args.instruction,args.kb,now()))
                store.event(c,{'kb':args.kb,'instruction':args.instruction})
            result = store.rules()
        elif c == 'rule-delete':
            with store.db:
                if not store.db.execute('DELETE FROM rules WHERE id=?',(args.id,)).rowcount: raise ValueError('Unknown rule')
                store.event(c,{'id':args.id})
            result = store.rules()
        elif c == 'reindex': result = store.reindex(args.provider,'hash-v1-512' if args.provider=='hash' else args.model)
        elif c in ('backup','export'):
            if args.destination.exists(): raise ValueError('Destination already exists; choose a new path.')
            args.destination.parent.mkdir(parents=True,exist_ok=True)
            if c == 'backup':
                dest = sqlite3.connect(args.destination)
                try: store.db.backup(dest)
                finally: dest.close()
            else:
                with store.db:
                    store.db.execute('BEGIN')
                    payload = {'overview':store.overview(),'documents':[store.show(r[0]) for r in store.db.execute('SELECT id FROM documents')],
                               'events':[dict(r) for r in store.db.execute('SELECT * FROM events')]}
                with args.destination.open('x',encoding='utf-8') as f: json.dump(payload,f,ensure_ascii=False,indent=2)
            result = {'saved':str(args.destination.resolve())}
        print(json.dumps(result,ensure_ascii=False,indent=2))
    except (ValueError,OSError,sqlite3.Error) as e:
        print(json.dumps({'error':str(e)},ensure_ascii=False),file=sys.stderr)
        return 1
    finally:
        if store: store.db.close()
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
