#!/usr/bin/env node
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
const args = process.argv.slice(2), projectIndex = args.indexOf('--project');
const global = args.includes('--global');
if ((!global && projectIndex < 0) || (global && projectIndex >= 0) || (projectIndex >= 0 && !args[projectIndex + 1])) {
  console.error('Usage: node install.mjs --global\n   or: node install.mjs --project /absolute/path/to/project'); process.exit(1);
}
const source = fileURLToPath(new URL('./capture-prototype', import.meta.url));
const destination = global ? path.join(os.homedir(), '.copilot', 'skills', 'capture-prototype') : path.resolve(args[projectIndex + 1], '.github', 'skills', 'capture-prototype');
try {
  try { await fs.access(destination); throw new Error(`Destination already exists; inspect it before replacing: ${destination}`); }
  catch (error) { if (error.code !== 'ENOENT') throw error; }
  await fs.cp(source, destination, { recursive: true, filter: file => !file.split(path.sep).includes('node_modules') && !file.endsWith('last-run.json') });
  const result = spawnSync(process.platform === 'win32' ? 'npm.cmd' : 'npm', ['ci', '--omit=dev'], { cwd: destination, stdio: 'inherit', shell: process.platform === 'win32' });
  if (result.status !== 0) throw new Error(`Dependency setup failed. Retry npm ci --omit=dev in ${destination}`);
  console.log(`\nInstalled: ${destination}\nOpen/reload your project in VS Code and invoke:\n/capture-prototype https://your-app.example\nThen operate Chrome and send: finish`);
} catch (error) { console.error(error.message); process.exitCode = 1; }
