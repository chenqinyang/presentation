# Capture Prototype for GitHub Copilot

Requires Node.js 22+, installed Google Chrome, and GitHub Copilot local Agent mode in VS Code. No separate model API key. Use local desktop VS Code; remote containers/SSH/WSL need a recorder running on the desktop host.

## Install

Extract the ZIP and open a terminal in `browser-prototype-kit`. Choose one:

```sh
# Available across local projects:
node install.mjs --global

# Or just one project:
node install.mjs --project "/absolute/path/to/your-project"
```

Installs into `~/.copilot/skills/capture-prototype` or `<project>/.github/skills/capture-prototype`, downloads pinned npm dependencies, and refuses to overwrite an existing skill. These locations are supported by [VS Code agent skills](https://code.visualstudio.com/docs/agent-customization/agent-skills).

## Use

Open your project, select Copilot **Agent** mode, and start a new chat. Reload VS Code if the skill is not listed. Enter:

```text
/capture-prototype https://your-application.example
```

Or say: “Use the capture-prototype skill to open this URL in Chrome, record my interactions until I say finish, and generate responsive offline HTML prototypes.”

Operate the launched Chrome window. Log in if needed; visit pages, demonstrate branches, menus, forms, filters and dialogs, and resize the window. The detached recorder continues after Copilot's response ends. When ready, send in the **same chat**:

```text
finish
```

Copilot stops recording, exports, checks and refines the prototype. If context is lost, invoke `/capture-prototype finish` from the same workspace. The agent handles this chat message; the recorder itself cannot read Copilot chat.

Output: `index.html`, self-contained HTML for each captured route, `coverage.json`, and `verify-report.json`. Double-click the index. No web server or application backend is required. Embedded original assets can make the HTML files large.

## Supported scope

Records DOM states, clicks, inputs, selections, relevant keys, hover, SPA routes, scrolling and viewport sizes. Captures original CSS, images, SVG references and fonts. Generates local transitions with guarded input values, retained CSS layout, embedded assets and blocked external connections. The skill guides Copilot through refinement when captured transitions alone are insufficient.

This version reproduces demonstrated workflows. It cannot infer every application behavior. Unseen inputs, server calculations, complex canvas/WebGL, shadow DOM, embedded frames, cross-tab flows and JavaScript-driven responsive changes can require custom work. Coverage reports identify boundaries; successful export is not proof of exact equivalence.

The original app uses its backend while recording; exported HTML does not. Visible data is saved locally. Passwords, hidden fields and explicitly private-marked regions are excluded. Never distribute the Chrome profile or raw captures with a prototype.

## Manual CLI

Replace the skill path with the installer output. Use a persistent local VS Code terminal if your agent host cannot retain detached processes.

```sh
node "/path/to/capture-prototype/scripts/prototype.mjs" doctor
node "/path/to/capture-prototype/scripts/prototype.mjs" start --url "https://your-app.example" --workspace "/path/to/project"
node "/path/to/capture-prototype/scripts/prototype.mjs" status --workspace "/path/to/project"
node "/path/to/capture-prototype/scripts/prototype.mjs" finish --workspace "/path/to/project"
node "/path/to/capture-prototype/scripts/prototype.mjs" export --workspace "/path/to/project" --out "/path/to/project/prototypes/demo"
node "/path/to/capture-prototype/scripts/prototype.mjs" verify --workspace "/path/to/project" --out "/path/to/project/prototypes/demo"
```

Verification exits with code 2 on failure and writes details. Let Copilot inspect and repair differences. For development, run `npm ci` then `npm test` inside `capture-prototype`; tests use a real local React SPA and installed Chrome.
