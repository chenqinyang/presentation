# Operations

Commands use `node "<skill>/scripts/prototype.mjs" <command>`. Select a project with `--workspace PATH` or a specific recording with `--session PATH`.

| Command | Behavior |
|---|---|
| `doctor` | Check Node and installed Google Chrome. |
| `start --url URL` | Launch visible Chrome in a dedicated persistent profile. Optional `--profile PATH`; never use the normal Chrome profile. `--headless` is for tests. |
| `status` | Inspect lifecycle and counts; report a dead process as interrupted. |
| `finish` | Request stop and flush assets; idempotent after stop. If still `stopping`, check status again. |
| `export --out PATH` | Generate HTML, index, editable model and coverage report. |
| `verify --out PATH` | Compare screenshots, exercise transitions, check network and overflow at 390/768/1440 pixels. Exit code 2 on failure. Default `--tolerance 0.02` allows 2% mismatched pixels. |

The original application calls its backend during recording. Referenced static assets are also downloaded. The recorder does not collect raw API response payloads, cookies or auth headers for export. The prototype uses no application or model APIs.

## Persistence

`start` launches a detached Node process and returns. The agent can end its turn. The `finish` chat message is handled by the agent; a shell process cannot read Copilot chat. If context is lost, invoke `/capture-prototype finish` in the same workspace.

The OS, host process policy, shutdown or Chrome crash can interrupt capture. Captures are checkpointed; interruption is not reported as successful completion. Existing session directories are never overwritten. For abrupt process termination, inspect `recording.json`, `states/` and `recorder.log` for manual recovery into a new directory; the asset manifest may be incomplete.

## Session files

```text
session.json           lifecycle, URL, PID, workspace, profile
events.jsonl           semantic actions and state references
recording.json         states, transitions and warnings
states/sN.html         script-free DOM snapshots
screenshots/sN.png     available reference captures
assets/manifest.json   resource URLs, hashes and MIME types
assets/<sha256>        original resource bytes
recorder.log           diagnostics
stop.json              explicit stop request
```

Raw captures can contain private visible data; the Chrome profile contains authenticated browsing state. Do not distribute these with prototypes. Password/hidden inputs and `data-prototype-private` regions are omitted. This is not a general-purpose personal-data detector.

## Fidelity

The baseline uses actual DOM/CSS/assets inside a sandboxed, full-width iframe, keeping captured CSS isolated from the export shell. Each page embeds the captured state graph, so local transitions can cross captured routes. Original application scripts never execute.

Inputs are editable, but guarded transitions only reproduce recorded values. Generalized save/search behavior requires local implementation. Rapid actions, animations, long asynchronous work, native dialogs, drag-and-drop, uploads, cross-tab flows, canvas/WebGL, shadow DOM, embedded frames and media may need custom reconstruction. Canvas is exported as a captured image. Hover CSS stays native; JavaScript hover transitions are best effort.

The collector follows loaded images/fonts/stylesheets, CSS imports and referenced URLs up to eight dependency passes. Individual assets are capped at 25 MB. Missing resources are reported. Responsive image candidates use captured currentSrc; alternate variants need additional collection. Browser/OS differences can affect pixels despite identical bytes.

Screenshots are taken close to DOM snapshots, not atomically. Investigate animation/timing differences. Overflow checks establish fit, not appearance fidelity at unseen widths. JavaScript-driven responsive components need captured widths, source reuse or reconstruction.
