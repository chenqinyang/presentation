---
name: capture-prototype
description: Launch a web application in visible Google Chrome, record the user's manual interactions until they say finish, then generate and refine responsive offline HTML prototypes with embedded assets and no application API calls. Use for capturing demonstrated application workflows, and for finish or status requests on an active capture.
---

# Capture Prototype

Use the bundled recorder and exporter, then refine the generated prototype. The baseline reproduces observed states and transitions; it does not infer arbitrary application or server behavior. A React repository, when available, is the best source for reusable components, styles and local data adapters.

## Setup

Resolve `<skill>` from this SKILL.md's absolute directory and `<workspace>` from the user's open project. Quote paths. Requires Node.js 22+ and installed Google Chrome on the user's desktop. For remote SSH, containers, WSL or Codespaces, run the recorder on the desktop host instead.

If dependencies are absent, run `npm ci --omit=dev --prefix "<skill>"`. Run `node "<skill>/scripts/prototype.mjs" doctor` once for a new installation. Do not silently substitute another browser.

The workspace pointer is `.prototype-captures/active.json`. Raw captures and the dedicated Chrome profile live under `.prototype-captures/`. Add `.prototype-captures/` to the workspace `.gitignore` when needed, preserving existing entries.

## Start

1. Obtain the target URL; ask only if it is missing.
2. Run `node "<skill>/scripts/prototype.mjs" start --url "<url>" --workspace "<workspace>"`.
3. Confirm the returned status is `recording`. On failure, inspect the error and `recorder.log`; a visible browser alone does not establish that capture started.
4. Tell the user to operate the launched Chrome window, demonstrate relevant pages and interaction branches, resize the window, and send **finish** in this same chat. They can log in manually. Visible page data is recorded; credentials and hidden fields are excluded.
5. End the chat turn while the detached recorder continues. Do not poll indefinitely, set a recording timeout, generate output early, stop on turn completion or operate the live application during the user's demonstration.

Use `status --workspace "<workspace>"` to inspect progress. If the host terminates background processes, use a persistent local VS Code terminal and disclose that limitation. The recorder remains active until finish or a browser/process failure.

## Finish and generate

On a standalone **finish** message, or an unambiguous request to finish the active capture:

1. Run `node "<skill>/scripts/prototype.mjs" finish --workspace "<workspace>"`. It flushes events, collects referenced static assets and closes only its own Chrome instance.
2. If status remains `stopping`, check status again after a short interval. Do not export while recording is active. Report interrupted/failed status accurately and preserve raw captures.
3. Choose a fresh output directory, normally `prototypes/<session-name>/`, then run:
   ```sh
   node "<skill>/scripts/prototype.mjs" export --workspace "<workspace>" --out "<output>"
   node "<skill>/scripts/prototype.mjs" verify --workspace "<workspace>" --out "<output>"
   ```
4. Read `coverage.json` and `verify-report.json`. Verification exit code 2 means checks failed. Inspect screenshots and failed transitions, repair the supported behavior, then rerun relevant checks.
5. Follow [refinement.md](references/refinement.md) to implement actual local behavior where recorded transitions are insufficient. Preserve observed content, original assets and fluid layout. Reuse original React source if available. Identify missing assets rather than silently inventing replacements.
6. Deliver links to the index, page prototypes and reports. State what was verified, what remains unsupported and whether refinement was performed. Export success alone does not prove application equivalence or pixel perfection.

## Output requirements

- One self-contained HTML entry for each captured URL/SPA route, plus an index. Files must work by double-clicking, without a server. Embed CSS, local JavaScript, images, icons, fonts and data.
- Retain original CSS media/container queries and fluid layout. Preserve meaningful max-width rules; do not freeze the capture width or scale screenshots to simulate responsiveness.
- Use local state and data. No production scripts, API clients, model API calls, service workers, analytics, remote resources or external navigation. Retain restrictive CSP and test with network blocked.
- The baseline follows recorded transitions and guards form values. Unsupported inputs/actions must be identified instead of displaying a false recorded result. Generalized behavior belongs in the refinement pass.
- Do not distribute cookies, Chrome profiles or raw captures with a prototype. Keep password, hidden and `data-prototype-private` content excluded.

Read [operations.md](references/operations.md) for CLI recovery, formats and fidelity boundaries. After changing the scripts, use `npm ci` then `npm test` in this directory for end-to-end validation with the included local React fixture.
