#!/usr/bin/env node
import fs from 'node:fs/promises';
import { openSync, closeSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn } from 'node:child_process';
import { parseArgs, readJSON, writeJSON, sleep, alive } from './lib/common.mjs';

const args = parseArgs(process.argv.slice(2));
const command = args._[0] || 'help';
const root = path.resolve(String(args.workspace || process.cwd()));
const pointer = path.join(root, '.prototype-captures', 'active.json');
const cliPath = fileURLToPath(import.meta.url);
async function sessionPath() {
  if (args.session) return path.resolve(String(args.session));
  const active = await readJSON(pointer, null);
  if (!active) throw new Error('No active recording in this workspace. Use start --url URL first, or pass --session PATH.');
  return active.session;
}
async function main() {
  if (command === 'doctor') {
    const { chromium } = await import('playwright');
    const browser = await chromium.launch({ channel: 'chrome', headless: true });
    console.log(JSON.stringify({ node: process.version, chrome: browser.version(), platform: process.platform, ready: true }, null, 2));
    await browser.close(); return;
  }
  if (command === 'start') {
    if (typeof args.url !== 'string' || !/^https?:\/\//i.test(args.url)) throw new Error('Provide an http(s) application URL with --url.');
    const active = await readJSON(pointer, null);
    if (active) {
      const previous = await readJSON(path.join(active.session, 'session.json'), {});
      if (['starting', 'recording', 'stopping'].includes(previous.status) && alive(previous.pid)) throw new Error(`A recording is already active: ${active.session}. Use finish or status.`);
    }
    const session = path.resolve(String(args.session || path.join(root, '.prototype-captures', new Date().toISOString().replace(/[:.]/g, '-'))));
    await fs.mkdir(path.dirname(session), { recursive: true });
    await fs.mkdir(session); // Refuse to overwrite an existing session.
    const profile = path.resolve(String(args.profile || path.join(root, '.prototype-captures', 'chrome-profile')));
    await writeJSON(path.join(session, 'session.json'), { version: 1, session, url: args.url, workspace: root, profile, headless: Boolean(args.headless), status: 'starting', created: new Date().toISOString() });
    const fd = openSync(path.join(session, 'recorder.log'), 'a');
    const child = spawn(process.execPath, [cliPath, '_record', '--session', session], { detached: true, stdio: ['ignore', fd, fd], windowsHide: true });
    closeSync(fd); child.unref();
    await writeJSON(pointer, { session });
    for (let i = 0; i < 100; i++) {
      const state = await readJSON(path.join(session, 'session.json'));
      if (state.status === 'recording') { console.log(JSON.stringify({ ...state, message: 'Recording is active. Operate Chrome, then send finish in the same agent chat.' }, null, 2)); return; }
      if (state.status === 'failed') throw new Error(state.error);
      if (!alive(child.pid)) throw new Error(`Recorder exited. Read ${path.join(session, 'recorder.log')}`);
      await sleep(200);
    }
    throw new Error(`Chrome is still starting. Run status --session "${session}"; do not start a duplicate.`);
  }
  if (command === '_record') { const { record } = await import('./lib/record.mjs'); await record(await sessionPath()); return; }
  if (command === 'status') {
    const session = await sessionPath();
    const state = await readJSON(path.join(session, 'session.json'));
    if (['starting', 'recording', 'stopping'].includes(state.status) && !alive(state.pid)) state.status = 'interrupted-process-exited';
    console.log(JSON.stringify(state, null, 2)); return;
  }
  if (command === 'finish') {
    const session = await sessionPath();
    let state = await readJSON(path.join(session, 'session.json'));
    if (state.status === 'failed') throw new Error(state.error);
    if (!['stopped', 'interrupted'].includes(state.status) && !alive(state.pid)) throw new Error('Recorder has exited unexpectedly. Raw captures are preserved; inspect recorder.log before recovery.');
    if (!['stopped', 'interrupted'].includes(state.status)) await writeJSON(path.join(session, 'stop.json'), { requested: new Date().toISOString() });
    for (let i = 0; i < 225; i++) {
      state = await readJSON(path.join(session, 'session.json'));
      if (['stopped', 'interrupted'].includes(state.status)) { console.log(JSON.stringify(state, null, 2)); return; }
      if (state.status === 'failed') throw new Error(state.error);
      await sleep(200);
    }
    console.log(JSON.stringify({ session, status: state.status, message: 'Still collecting referenced assets. Check status before exporting.' }, null, 2)); return;
  }
  if (command === 'export' || command === 'verify') {
    const session = await sessionPath();
    const output = path.resolve(String(args.out || path.join(session, 'prototype')));
    if (command === 'export') {
      const { generate } = await import('./lib/export.mjs');
      console.log(JSON.stringify(await generate(session, output), null, 2));
    } else {
      const { verify } = await import('./lib/verify.mjs');
      const report = await verify(session, output, args);
      console.log(JSON.stringify({ passed: report.passed, statesCompared: report.visual.length, transitionsChecked: report.transitions.length, networkAttempts: report.networkAttempts.length, report: path.join(output, 'verify-report.json') }, null, 2));
      if (!report.passed) process.exitCode = 2;
    }
    return;
  }
  if (command !== 'help') throw new Error(`Unknown command: ${command}`);
  console.log(`Capture Prototype (Node 22+, installed Google Chrome)

node scripts/prototype.mjs doctor
node scripts/prototype.mjs start --url https://app.example --workspace /path/to/project
node scripts/prototype.mjs status --workspace /path/to/project
node scripts/prototype.mjs finish --workspace /path/to/project
node scripts/prototype.mjs export --workspace /path/to/project --out /path/to/prototype
node scripts/prototype.mjs verify --workspace /path/to/project --out /path/to/prototype

Use --session PATH to select a particular capture. start also accepts --profile PATH
(a dedicated profile only) and --headless for testing. Runs locally; no model API key.
The agent handles the chat word finish. The recorder itself does not read your chat.`);
}
main().catch(error => { console.error(error.stack || error.message); process.exitCode = 1; });
