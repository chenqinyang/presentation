import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import http from 'node:http';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { promisify } from 'node:util';
import { execFile } from 'node:child_process';
import { build } from 'esbuild';
import { chromium } from 'playwright';
import { installRecorder } from '../scripts/lib/instrument.mjs';
import { AssetStore } from '../scripts/lib/assets.mjs';
import { generate } from '../scripts/lib/export.mjs';
import { verify } from '../scripts/lib/verify.mjs';
import { hash, writeJSON, readJSON, sleep } from '../scripts/lib/common.mjs';
const run = promisify(execFile);
const root = fileURLToPath(new URL('..', import.meta.url));
const cli = path.join(root, 'scripts/prototype.mjs');

async function fixtureServer() {
  const bundled = await build({ entryPoints: [path.join(root, 'tests/fixture.jsx')], bundle: true, write: false, format: 'iife', define: { 'process.env.NODE_ENV': '"production"' } });
  const css = `@import url('/extra.css');@font-face{font-family:CaptureInter;src:url('/inter.woff2') format('woff2');font-weight:400}*{box-sizing:border-box}body{margin:0;background:#f4f7fb;color:#142e44;font:16px CaptureInter,sans-serif}header{display:flex;align-items:center;gap:16px;padding:20px;background:white}header img{width:32px;height:32px}nav{margin-left:auto;display:flex;gap:8px}main{width:100%;max-width:1100px;margin:auto;padding:28px}button,select,input{font:inherit;padding:8px 12px;margin:4px;border:1px solid #bbc9d5;border-radius:6px;background:white}button:hover{background:#e0efff}.cards{display:grid;grid-template-columns:1fr 1fr;gap:20px}section{background:white;padding:20px;border-radius:10px}[role=dialog]{position:fixed;inset:20% 25%;background:white;border:2px solid #2384ee;padding:30px;box-shadow:0 0 0 100vmax #0007;z-index:9}input[type=password],[data-prototype-private]{display:none}@media(max-width:700px){.cards{grid-template-columns:1fr}header{flex-wrap:wrap}nav{margin-left:0}main{padding:16px}[role=dialog]{inset:20% 5%}}`;
  const font = await fs.readFile(path.join(root, 'node_modules/@fontsource/inter/files/inter-latin-400-normal.woff2'));
  const mark = '<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32"><rect width="32" height="32" rx="8" fill="#1676eb"/><path d="M8 22 16 8 24 22" fill="none" stroke="white" stroke-width="3"/></svg>';
  const server = http.createServer((req, res) => {
    const resources = { '/app.js': ['text/javascript', bundled.outputFiles[0].contents], '/style.css': ['text/css', css], '/extra.css': ['text/css', '.icon{display:inline-block;width:20px;height:20px;background:url("/mark.svg") center/contain}'], '/mark.svg': ['image/svg+xml', mark], '/sprite.svg': ['image/svg+xml', '<svg xmlns="http://www.w3.org/2000/svg"><symbol id="star" viewBox="0 0 32 32"><path fill="#1676eb" d="M16 2 20 11 30 12 22 19 24 30 16 24 8 30 10 19 2 12 12 11Z"/></symbol></svg>'], '/inter.woff2': ['font/woff2', font] };
    const [type, body] = resources[req.url] || ['text/html', '<!doctype html><html><head><title>Acme</title><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="stylesheet" href="/style.css"></head><body><div id="root"></div><script src="/app.js"></script></body></html>'];
    res.writeHead(200, { 'content-type': type }); res.end(body);
  });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  return { server, url: `http://127.0.0.1:${server.address().port}`, font };
}

test('React interaction capture → multi-page self-contained HTML → offline replay and responsive checks', { timeout: 180000 }, async () => {
  const fixture = await fixtureServer();
  const temp = await fs.mkdtemp(path.join(os.tmpdir(), 'prototype-integration-'));
  const session = path.join(temp, 'capture'), output = path.join(temp, 'prototype');
  await fs.mkdir(path.join(session, 'states'), { recursive: true });
  await fs.mkdir(path.join(session, 'screenshots'));
  const browser = await chromium.launch({ channel: 'chrome', headless: true });
  const context = await browser.newContext({ viewport: { width: 1280, height: 900 } });
  const page = await context.newPage(), assets = new AssetStore(session, context);
  const data = { states: [], edges: [], warnings: [] };
  const lookup = new Map();
  let pending, last, chain = Promise.resolve();
  async function save(snapshot, reason) {
    if (!snapshot) return;
    const key = hash(JSON.stringify([snapshot.html, snapshot.url, snapshot.viewport, snapshot.scroll]));
    if (lookup.has(key)) return lookup.get(key);
    const id = `s${data.states.length + 1}`, state = { ...snapshot, id, reason, file: `states/${id}.html` };
    data.states.push(state); lookup.set(key, state);
    await fs.writeFile(path.join(session, state.file), snapshot.html);
    return state;
  }
  function complete(state) { if (pending && state && pending.from !== state.id) data.edges.push({ ...pending, to: state.id }); pending = null; }
  context.on('response', response => assets.response(response));
  await context.exposeBinding('__prototypeEmit', (_, event) => {
    chain = chain.then(async () => {
      if (event.type === 'action') {
        const before = await save(event.before, 'before'), previous = last;
        complete(before);
        pending = { from: ['input', 'change'].includes(event.action.type) ? (previous || before).id : before.id, action: event.action };
        last = before;
      } else { const state = await save(event.state, event.reason); complete(state); if (state) last = state; }
    }); return chain;
  });
  await context.addInitScript(installRecorder);
  async function settled(screenshot = true) {
    await sleep(650); await chain;
    if (screenshot && last && !last.screenshot) { last.screenshot = `screenshots/${last.id}.png`; await page.screenshot({ path: path.join(session, last.screenshot), animations: 'disabled' }); }
  }
  try {
    await page.goto(fixture.url + '/orders'); await page.locator('h1').waitFor(); await settled();
    await page.getByRole('button', { name: 'View order' }).click(); await settled();
    await page.getByRole('button', { name: 'Close', exact: true }).click(); await settled();
    await page.getByLabel('Status').selectOption('Pending'); await settled();
    await page.getByRole('button', { name: 'Customers', exact: true }).click(); await settled();
    await page.getByLabel('Name', { exact: true }).fill('Jamie'); await settled();
    await page.getByRole('button', { name: 'Save', exact: true }).click(); await settled();
    await page.setViewportSize({ width: 390, height: 900 }); await settled();
    await page.evaluate(() => window.__prototypeRecorder.stop());
    await chain; await assets.complete(data.states);
    await writeJSON(path.join(session, 'session.json'), { status: 'stopped' });
    await writeJSON(path.join(session, 'recording.json'), { ...data, states: data.states.map(({ html, ...state }) => state) });
    const result = await generate(session, output);
    assert.equal(result.pages, 2);
    assert.ok(result.transitions >= 6);
    const manifest = await readJSON(path.join(session, 'assets/manifest.json'));
    assert.equal(manifest[fixture.url + '/inter.woff2'].sha256, hash(fixture.font));
    const model = await readJSON(path.join(output, 'model.json'));
    const pageHTML = await fs.readFile(path.join(output, model.routes[0].file), 'utf8');
    assert.ok(!pageHTML.includes('never-export-this'));
    assert.ok(!pageHTML.includes('private-value-must-disappear'));
    assert.ok(pageHTML.includes('data:font/woff2;base64,'));
    assert.ok(model.states[0].html.includes('href="#sprite-'), 'External SVG sprites must become inline definitions.');
    const offline = await browser.newContext({ viewport: { width: 1280, height: 900 }, offline: true });
    const local = await offline.newPage();
    let requests = 0; local.on('request', r => { if (/^https?:/.test(r.url())) requests++; });
    await local.goto(pathToFileURL(path.join(output, model.routes[0].file)).href);
    await local.waitForFunction(() => window.__prototypeReadyState);
    let frame = local.frameLocator('#prototype-frame');
    await frame.getByRole('button', { name: 'View order' }).click();
    await frame.getByRole('dialog').waitFor();
    await frame.getByRole('button', { name: 'Close', exact: true }).click();
    await frame.getByRole('dialog').waitFor({ state: 'detached' });
    await frame.getByLabel('Status').selectOption('Pending');
    await frame.getByText('1 pending order', { exact: true }).waitFor();
    await frame.getByRole('button', { name: 'Customers', exact: true }).click();
    await frame.getByLabel('Name', { exact: true }).fill('Jamie');
    await frame.getByRole('button', { name: 'Save', exact: true }).click();
    await frame.getByText('Saved name: Jamie', { exact: true }).waitFor();
    await frame.getByLabel('Name', { exact: true }).fill('Unseen');
    await frame.getByRole('button', { name: 'Save', exact: true }).click();
    assert.equal(await frame.getByText('Saved name: Jamie', { exact: true }).count(), 1);
    assert.ok(await local.evaluate(() => window.__prototypeLastUnsupported));
    assert.equal(requests, 0);
    await offline.close();
    const report = await verify(session, output);
    await fs.writeFile(path.join(root, 'tests/last-run.json'), JSON.stringify({ temp, result, report }, null, 2));
    assert.equal(report.networkAttempts.length, 0);
    assert.equal(report.errors.length, 0, JSON.stringify(report.errors));
    assert.ok(report.visual.every(v => v.passed), JSON.stringify(report.visual));
    assert.ok(report.responsive.every(v => v.passed));
    assert.ok(report.transitions.every(v => v.passed), JSON.stringify(report.transitions));
  } finally { await browser.close(); await new Promise(resolve => fixture.server.close(resolve)); }
});

test('detached CLI recorder survives start command, stops on finish, and exports', { timeout: 90000 }, async () => {
  const fixture = await fixtureServer();
  const workspace = await fs.mkdtemp(path.join(os.tmpdir(), 'prototype-cli-'));
  let session;
  try {
    const started = await run(process.execPath, [cli, 'start', '--url', fixture.url + '/orders', '--workspace', workspace, '--headless']);
    const state = JSON.parse(started.stdout); session = state.session;
    assert.equal(state.status, 'recording');
    await sleep(2600);
    const status = JSON.parse((await run(process.execPath, [cli, 'status', '--workspace', workspace])).stdout);
    assert.equal(status.status, 'recording');
    assert.ok(status.stateCount >= 1);
    const finished = JSON.parse((await run(process.execPath, [cli, 'finish', '--workspace', workspace])).stdout);
    assert.equal(finished.status, 'stopped');
    const exported = JSON.parse((await run(process.execPath, [cli, 'export', '--workspace', workspace])).stdout);
    assert.equal(exported.pages, 1);
    await assert.rejects(run(process.execPath, [cli, 'start', '--url', fixture.url, '--workspace', workspace, '--session', session, '--headless']));
  } finally {
    if (session) await writeJSON(path.join(session, 'stop.json'), { requested: true });
    await new Promise(resolve => fixture.server.close(resolve));
  }
});
