import React, { useState } from 'react';
import { createRoot } from 'react-dom/client';

function App() {
  const [route, setRoute] = useState(location.pathname);
  const [open, setOpen] = useState(false);
  const [filter, setFilter] = useState('All');
  const [name, setName] = useState('Alex');
  const [saved, setSaved] = useState('Alex');
  function navigate(to) { history.pushState({}, '', to); setRoute(to); }
  return <><header><img src="/mark.svg" alt="Mark"/><strong>Acme Workspace</strong><nav><button onClick={() => navigate('/orders')}>Orders</button><button onClick={() => navigate('/customers')}>Customers</button></nav></header><main>
    <h1><svg width="32" height="32" aria-label="Star icon"><use href="/sprite.svg#star"/></svg> {route === '/customers' ? 'Customers' : 'Orders'}</h1>
    <div className="cards"><section><h2>Overview</h2><p>Responsive content with the original font.</p><span className="icon" aria-hidden="true"/></section><section><h2>Activity</h2><p>Latest updates</p></section></div>
    {route !== '/customers' ? <><label>Status <select aria-label="Status" value={filter} onChange={e => setFilter(e.target.value)}><option>All</option><option>Pending</option></select></label><p id="result">{filter === 'All' ? '3 orders' : '1 pending order'}</p><button onClick={() => setOpen(true)}>View order</button>{open && <div role="dialog"><h2>Order #1042</h2><p>Pending · $120</p><button onClick={() => setOpen(false)}>Close</button></div>}</> : <><label>Name <input aria-label="Name" value={name} onChange={e => setName(e.target.value)}/></label><button onClick={() => setSaved(name)}>Save</button><p id="saved">Saved name: {saved}</p></>}
    <p><a href="/orders" onClick={e => { e.preventDefault(); navigate('/orders'); }}>Return to orders</a></p>
    <input type="password" value="never-export-this" readOnly aria-label="Secret"/>
    <div data-prototype-private>private-value-must-disappear</div>
  </main></>;
}
createRoot(document.getElementById('root')).render(<App/>);
